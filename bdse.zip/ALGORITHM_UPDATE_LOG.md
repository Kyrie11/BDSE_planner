# v49 DBAP — Deployment-Boundary Action Preservation

## 日期

2026-07-29

## 基于 v48 实验的结论

- v48 gate FAIL，closed-loop 被正确阻止；不是 CL20 调用缺失。
- certificate/fallback 层有效：certified-pair 0.831，fallback 0.162。
- pair interface 仍是主错误：dense near-tie 约 0.683，pair near-tie 0.460；pair-full match 0.272。
- pair-full→budget harmful compression 仅 0.024，说明 compression 已不是主矛盾。
- interaction budget fraction 0.948，跨 family 竞争失败。
- 平均只选 7.403/16 atoms，v48 实际验证的是 anytime early certificate，不是 strict fixed-budget action preservation。
- validation 未计算真实 pair-full/family collapse，best-checkpoint score 使用弱代理。

## 算法修改

### 1. Pure LOO deployment-boundary criticality

文件：`bdse/model/losses.py`

- `positive_support_floor` 默认改为 0；
- 新增 `target_top_k_atoms`；
- 新增 `min_relative_gain`；
- v49 配置关闭旧 `critical_pair` / `critical_proposal` 与 interaction-only critical target；
- 降低 general proposal 与 interaction boost，增强纯 CF pair/proposal listwise objective。

目的：避免所有微小正 support atom 获得 target mass，使 pair head 只拟合真正会增加 boundary deficit 的单位成本 evidence。

### 2. Bounded uncertainty-gated sparse residual

文件：`bdse/model/bdse_model.py`

新增 `_confidence_shrunk_residual_pair_delta_np`。部署 margin 为：

`local + trust * residual`，其中 `trust <= 0.35`，并由以下项共同缩小：

- residual variance；
- local margin 是否接近边界；
- residual 与 local 的原始符号冲突；
- residual/local 幅值异常。

修复 v48 先形成 `local+residual` 后再检测冲突、导致约 80% residual 仍保留的问题。

### 3. Exact-budget nested AOCC

文件：`bdse/planner/selector.py`

新增配置：

- `adverse_certificate_fill_to_budget_after_certified`；
- `adverse_certificate_max_interaction_prefix_fraction`。

行为：

- 首次认证后记录 first-certified prefix；
- 继续生成完整 nested order；
- materialize 严格 fixed-B prefix；
- 即使剩余 atom 的 certificate gain 为 0，也使用确定性成本顺序补齐；
- 每个 prefix 限制 interaction family 比例。

新增诊断：

- `aocc_first_certified_prefix_length`；
- `aocc_first_certified_cost`；
- `aocc_fill_to_budget_after_certified`；
- `aocc_max_interaction_prefix_fraction`。

### 4. Exact validation and checkpoint selection

文件：`bdse/experiments/train.py`

Validation 新增：

- exact pair-full tournament action；
- budget-vs-pair-full；
- dense→pair interface flip/harm；
- pair→budget compression flip/harm；
- selector diagnostics/family composition；
- planner latency；
- fixed-budget fill。

`_validation_fixed_budget_critical_score` 不再在缺失 pair-full 时回退到 sparse-full；缺失 pair/family diagnostics 会被显式惩罚。

### 5. Gate aligned with fixed-budget claim

文件：`bdse/tools/check_v48_dbce_gate.py`

新增：

- `--min-budget-fill-fraction`，默认 0.95；
- 输出 fixed-budget fill。

### 6. Cache provenance

文件：

- `bdse/experiments/preprocess.py`
- `bdse/data/nuplan_dataset.py`

新增：

- `--resume-require-config-match`；
- split 级 `cache_provenance.json`；
- config mismatch 或 legacy cache 无 provenance 时拒绝 strict resume。

### 7. Config and execution

新增：

- `bdse/configs/v49_bdse_dbap_train_2gpu.yaml`；
- `bdse/configs/v49_bdse_dbap_cl.yaml`；
- `run_v49_dbap.sh`；
- `V49_DBAP_NEXT_COMMANDS.sh`；
- `BUILD_MATCHED_TEST_SET.sh`。

两张 A30：训练 DDP；open-loop 与 closed-loop 按场景/token 分片并行。Control freshness 现在绑定 calibration provenance 与 val_tune manifest。

## Test 构建参数修复

相对上传的“快速生成”命令：

- 使用全新 `bdse_test_v49_matched` 输出目录；
- `--include-drivable-polygons`，与 train/val 诊断一致；
- 移除 `--max-samples-per-log 512`，与 train/val 诊断中的 `None` 对齐；
- 保留 stride=10、initial、teacher stride=1、candidate-aware、crosswalk=false；
- 启用 resume validation 与 config provenance。

## 验证

- `python -m compileall -q bdse`：PASS；
- 两个 v49 YAML 加载：PASS；
- 三个 shell 脚本 `bash -n`：PASS；
- `pytest -q`：161 passed，5 warnings。

## 重要限制

代码修复只保证目标、部署接口、验证指标和 fixed-budget claim 更一致。是否改善 teacher match、regret、latency 与 closed-loop，必须由 v49 实验确认；不得预先声称 PASS。

---

# BDSE Algorithm Update Log

> 维护规则：后续每一轮算法修改都追加一条记录；不要覆盖旧记录。每条记录至少包含：版本、动机、修改文件、关键超参数、验证结果、失败样本结论、下一步，以及“禁止重复尝试”。

## Baseline context

- Paper: `Budgeted Decision-Sufficient Evidence for Interactive Autonomous Planning`
- Dataset/protocol: nuPlan DB train/validation; 2 s history, 8 s horizon; candidate bank default K=32; evidence budget B=16; proposal Top-M=64.
- Runtime checkpoint for controlled selector experiments: `outputs_v30/train/bdse_v30_pmvrbsr.best.pt`.
- v39 runtime outputs: 1000 aligned validation samples.
- Strict experimental principle: change the runtime selector first while freezing checkpoint, candidate bank, Top-M, B, pair queries, teacher and evaluation set.

---

## 2026-07-20 — v40 Lex-DACC

### Motivation

The v39 DACC strict runtime gate failed:

| Metric | v39 DACC | Gate / control condition |
|---|---:|---:|
| Teacher action match | 0.238 | absolute pass; paired pass |
| B=16 vs full-interface | 0.206 | absolute pass; paired LCB fail |
| Deployment target action preserved | 0.919 | required >= 0.950 |
| Winner-rival sign accuracy | 0.636914 | paired pass |
| Effective query count | 5383.152 | budget pass |

Paired `B=16 vs full` difference was +0.001, but the one-sided 95% LCB was -0.003354, below the strict -0.002 non-inferiority margin.

### Root-cause diagnosis

1. **Finite soft action penalty is incompatible with the gate.**
   - v39 adds `deployment_coreset_action_weight=4.0` to a continuous distortion loss.
   - On the 81 diagnostic action-flip samples, the deployment objective starts near 4, showing that the search accepts a deployment-action change whenever score/gap/margin distortion savings exceed the finite penalty.
   - Action preservation is therefore encouraged, not guaranteed.

2. **Top-8 exact screening can miss a preserving deletion.**
   - MARS is used to screen removal candidates, and only the top 8 receive exact deployment evaluation.
   - The surrogate and final deployment operator are not identical, so a preserving deletion can fall outside top 8.

3. **Generic post-fill can invalidate the DACC result.**
   - DACC diagnostics were computed before `_complete_safety_aware_selection()`.
   - The post-fill/quota logic can exchange atoms afterward.
   - Two observed samples reported target preservation in selector diagnostics but the actual final `bdse_action` differed.

4. **The failure is not caused by neural query budget or checkpoint capacity at this stage.**
   - v39 changed only 30/1000 final actions versus MARS control.
   - Query-count and all absolute safety/recall gates passed.
   - A counterfactual using the already logged DACC Top-M deployment target gives:
     - teacher match: 0.239; paired diff +0.001; LCB -0.004934, passing the -0.005 margin;
     - B-vs-full: 0.213; paired diff +0.008; LCB +0.001856, passing the -0.002 margin.
   - Therefore the first controlled intervention is to enforce target-action preservation, not to retrain the checkpoint.

### Algorithm modification

New runtime selector: **Lexicographic Deployment-Aligned Certificate Coreset (Lex-DACC)**.

Search priority:

1. preserve the exact full-Top-M deployment action whenever a feasible candidate exists;
2. among preserving subsets, minimize exact deployment score/gap/margin distortion;
3. accept an action-changing step only when no preserving step exists in the configured exact scan;
4. attempt exact one-swap repair and guided two-swap repair if the final greedy subset still changes the target action;
5. re-evaluate the actual post-fill set with the deployment callback, and revert post-fill when it breaks an action that DACC had preserved.

The deployment callback is unchanged and includes the actual downstream decision path: final rival graph, normalized antisymmetric pair margins, soft-min tournament, hard safety filtering, utility refinement, and all-flagged risk guard.

### Runtime/query properties

- Neural evidence queries: unchanged.
- Evidence budget: B=16, unchanged.
- Proposal pool: Top-M=64, unchanged.
- Pair-query budget: unchanged.
- Extra cost: deterministic CPU/Numpy deployment evaluations over already cached pair deltas.
- Exact-evaluation memoization remains active.

### Modified / added files

- `bdse/planner/selector.py`
  - lexicographic removal/exchange objective;
  - preserving-candidate scan expansion;
  - one/two-swap repair;
  - post-fill deployment audit and conditional revert;
  - additional diagnostics.
- `bdse/planner/nuplan_planner.py`
  - v40 selector aliases and config plumbing.
- `bdse/configs/v40_bdse_lexdacc_fast_cl.yaml`
- `bdse/configs/v40_bdse_lexdacc_fallback_fast_cl.yaml`
- `bdse/configs/v40_bdse_mars_control_fast_cl.yaml`
- `bdse/tools/check_v40_lexdacc_gate.py`
- `bdse/tests/test_v40_lexdacc.py`
- `run_v40_lexdacc.sh`

### New configuration

```yaml
selector_cap_mode: lexicographic_deployment_coreset
deployment_coreset_lexicographic_action_preservation: true
deployment_coreset_preservation_scan_candidates: 0  # scan all only if top-k has no preserving deletion
deployment_coreset_repair_one_swap: true
deployment_coreset_repair_two_swap_candidates: 256
```

### Verification completed in delivery environment

- `python -m py_compile`: passed.
- `bash -n run_v40_lexdacc.sh`: passed.
- full test suite: **120 passed, 5 warnings**.
- New regression tests verify:
  1. preserving deletion outside cheap exact top-1 is discovered;
  2. a destructive post-fill action flip is detected and reverted;
  3. v40 main/control/fallback configs are distinct and strict.

### Verification still required in nuPlan environment

- Strict 1000-scene open-loop runtime gate.
- CPU selector latency distribution, especially p95/p99.
- CL20 smoke test only after runtime gate passes.
- CL100 paired scenario-transition analysis.

### Do not repeat

- Do not increase the finite action penalty and call it a hard preservation guarantee.
- Do not use only Top-8 surrogate candidates without exact preserving-candidate expansion.
- Do not trust pre-post-fill DACC diagnostics as the final executed action.
- Do not change checkpoint and selector simultaneously before isolating the runtime effect.
- Do not launch closed-loop or finetuning when the strict runtime gate fails.
- Do not judge CL20 only by aggregate score; one binary scenario changes a mean by 0.05.

### Next decision rule

- If v40 passes strict open-loop gate and selector latency is acceptable: run CL20, then CL100.
- If target preservation remains below 0.95: inspect `forced_action_flip_steps`, repair success, and per-scene exact-evaluation counts; next candidate is beam-search deletion with action-preserving state dominance, not a larger soft penalty.
- If preservation passes but paired B-vs-full still fails: the Top-M target itself is not aligned enough with dense full-interface; next modification should redefine the deployment target or improve full-interface pair/local calibration.
- If open-loop passes but closed-loop safety regresses: keep Lex-DACC fixed and tune a separately identifiable safety fallback using paired collision/TTC transition counts.

---

## Append-only template

```markdown
## YYYY-MM-DD — version/name
### Motivation
### Hypothesis
### Changes
### Files/config
### Controlled variables
### Validation
### Result
### Failure slices
### Do not repeat
### Next step
```

---

## 2026-07-20 — v41 PR-DACC (Path-Relaxed Deployment-Aligned Certificate Coreset)

### Motivation

The v40 strict 1000-scenario runtime gate still failed, but only one hard condition failed:

| Metric | v40 PR predecessor | Gate / control condition | Status |
|---|---:|---:|---|
| Teacher action match | 0.239 | paired LCB >= -0.005 | pass, LCB -0.003937 |
| B=16 vs full-interface | 0.209 | paired LCB >= -0.002 | pass, LCB -0.001200 |
| Winner-rival sign accuracy | 0.638470 | paired LCB >= -0.005 | pass, LCB -0.003047 |
| Deployment target action preserved | **0.946** | **>= 0.950** | **fail by 4/1000 scenarios** |
| Effective query count | 5383.152 | unchanged budget | pass |

The v40 main output contained 54 target-action preservation failures.

### Failure slices and diagnosis

1. **The finite-penalty problem was fixed, but the remaining search is path dependent.**
   - Failed samples averaged **6.35 forced action-flip deletion steps** versus 0.013 on preserved samples.
   - Failed samples averaged 306.61 expanded exact deletion scans and 750.41 deployment evaluations.
   - Thus v40 already exhausts every feasible one-step deletion whenever the cheap top-k has no preserving candidate; the problem is no longer a missed top-k item at one state.

2. **The single greedy subset path reaches a dead end.**
   - Lex-DACC keeps only one subset after every deletion.
   - It can choose an action-preserving deletion that is locally best but later reaches a cardinality where every possible next deletion changes the target action.
   - A different earlier branch, or a branch that temporarily changes the action and later restores it, is never retained.

3. **The local repair radius is insufficient.**
   - Every failed sample exhaustively evaluated 224 one-swap candidates.
   - Every failed sample evaluated the configured top 256 two-swap candidates.
   - Only 4/1000 total samples were repaired by v40, and none of the final 54 failures were repairable by the retained one/two-swap search.
   - Increasing the same local-swap candidate count alone is therefore not the primary algorithmic fix.

4. **A residual graph mismatch remained in the cheap branch screen.**
   - v40 exact subset evaluation uses `rival_pair_atom_delta/rival_pair_indices`, which drive the final tournament.
   - The cheap deletion/swap screen still receives `pair_atom_delta/pair_indices`, the selector graph.
   - This does not change exact decisions, but it can prevent a useful branch from entering a bounded multi-path search.

5. **The failure is localized to coreset search rather than checkpoint/query capacity.**
   - All paired non-inferiority tests passed.
   - Query counts are exactly unchanged from the MARS control.
   - 49/54 failed v40 scenes selected the same final action as the MARS control.
   - Therefore v41 keeps the v30 checkpoint, B=16, Top-M, candidate bank, teacher, pair-query outputs and validation scenarios fixed.

### Hypothesis

Target-action preservation under a cardinality/budget constraint is not a monotone property along a greedy deletion path. A bounded subset-lattice beam that retains:

- exact target-preserving states; and
- a small, action-diverse set of temporarily mismatching states

can recover feasible final B=16 subsets that a single-path lexicographic greedy plus local exchange cannot reach.

### Algorithm changes

New runtime selector alias: **PR-DACC / Path-Relaxed DACC**.

1. **Deployment-graph-aligned screening**
   - When enabled, the coreset search receives the already queried final rival pair graph.
   - Exact evaluator and cheap screen now use the same pair index/delta family.
   - Rival graph weights are set to one because the deployed tournament is unweighted over its rival sets.

2. **Failure-triggered action-diverse beam search**
   - Triggered only when lexicographic deletion and one/two-swap repair still change the Top-M deployment action.
   - Starts from the complete active Top-M decision atom set.
   - Searches exactly the same final cardinality as the greedy B=16 set.
   - Retains both preserving states and a configured fraction of mismatching states.
   - Mismatching states are diversified by their exact deployed action so the beam does not collapse to one wrong winner.
   - Branch candidates combine four cheap rankings:
     - deployment distortion screen;
     - low target-action pair impact;
     - target-harming oriented contribution;
     - low proposal prior.
   - Every retained child is evaluated by the unchanged exact downstream deployment callback.
   - A beam result replaces v40 only when it exactly restores the target action and satisfies the budget.

3. **Bounded computation and unchanged model queries**
   - Beam is disabled on the 94.6% v40-preserved cases.
   - Default bound: width 12, branch 14, at most 2400 new exact subset evaluations per triggered scene.
   - No extra neural inference or evidence query is performed.

### Configuration

```yaml
selector_cap_mode: path_relaxed_deployment_coreset
deployment_coreset_use_deployment_pair_graph: true
deployment_coreset_beam_width: 12
deployment_coreset_beam_branch: 14
deployment_coreset_beam_max_evaluations: 2400
deployment_coreset_beam_mismatch_fraction: 0.42
```

The v40 lexicographic scan, one-swap repair, guided two-swap repair and post-fill audit remain enabled.

### Modified / added files

- `bdse/planner/selector.py`
  - bounded fixed-cardinality deletion-lattice beam;
  - action-diverse beam pruning;
  - target-oriented branch features;
  - beam diagnostics and config plumbing;
  - new PR-DACC aliases.
- `bdse/planner/nuplan_planner.py`
  - optional rival-graph-aligned coreset search;
  - v41 beam config plumbing and diagnostics.
- `bdse/configs/v41_bdse_prdacc_fast_cl.yaml`
- `bdse/configs/v41_bdse_prdacc_fallback_fast_cl.yaml`
- `bdse/configs/v41_bdse_mars_control_fast_cl.yaml`
- `bdse/tools/check_v41_prdacc_gate.py`
- `bdse/tests/test_v41_prdacc.py`
- `run_v41_prdacc.sh`

### Controlled variables

Unchanged:

- checkpoint: `outputs_v30/train/bdse_v30_pmvrbsr.best.pt`;
- validation scenarios/order;
- candidate trajectories and K;
- proposal Top-M and evidence bank;
- budget B=16;
- neural pair/local predictions;
- teacher labels;
- final tournament, safety guard, utility refinement and all-flagged guard;
- MARS control configuration.

### Validation completed in the delivery environment

- all Python files compile;
- `bash -n run_v41_prdacc.sh` passes;
- full test suite: **122 passed, 5 warnings**;
- new synthetic regression verifies a case where:
  - the target action disappears at an intermediate cardinality;
  - the v40 single path ends with the wrong action;
  - PR-DACC keeps a temporary mismatch branch and restores the target at the final budget;
- v41 configs load and require the rival graph plus bounded beam.

### Runtime validation still required

No nuPlan cache or v30 checkpoint is available in the delivery environment, so no claim is made that v41 already passes the 1000-scene gate.

Inspect after running:

```text
selector_deployment_coreset_target_action_preserved
selector_deployment_coreset_beam_attempted
selector_deployment_coreset_beam_success
selector_deployment_coreset_beam_evaluations
selector_deployment_coreset_beam_depth
selector_deployment_coreset_beam_peak_width
selector_deployment_coreset_search_uses_rival_graph
```

### Do not repeat

- Do not lower the 0.95 gate or relabel the v40 result as a pass.
- Do not increase `deployment_coreset_action_weight`; v40 already uses a true lexicographic comparison.
- Do not only increase the two-swap top-k and treat it as a path-dependence solution.
- Do not enable a full beam on every scenario; it wastes runtime on already-preserved samples.
- Do not change checkpoint or finetune while testing v41 runtime search.
- Do not compare v41 against a newly changed control; retain the frozen MARS control.
- Do not run closed loop until the strict open-loop gate passes.

### Next decision rule

- If preservation reaches >=0.95 and all paired gates pass: measure selector evaluation count/latency, then run CL20 and CL100.
- If beam success recovers at least 4 scenes but another paired metric fails: inspect the exact recovered/lost action transitions before changing beam width.
- If beam is attempted on the 54-like failures but success remains near zero: the target action may be infeasible at B=16 for those scenes; next step is a target-feasibility diagnostic or deployment-target redefinition, not a larger blind beam.
- If beam reaches the 2400-evaluation cap before full depth: increase the cap only after confirming branch diversity is useful; do not increase width, branch and cap simultaneously.

---

## v42 — CBL-DACC: Counterfactual Budget-Layer Deployment-Aligned Certificate Coreset

### Date / input

- Input code: user-provided `bdse.zip` containing v41 PR-DACC.
- Runtime result: user-provided `outputs_v41.zip`, 1000 validation scenarios, frozen v30 checkpoint.
- Only the strict runtime gate was run; no closed-loop or finetune result is used in this iteration.

### Observed v41 runtime result

The v41 gate failed only on:

```text
selector_deployment_coreset_target_action_preserved = 0.947 < 0.950
```

All other strict comparisons passed:

```text
teacher_action_match                  = 0.239
paired teacher LCB                    = -0.0039372  (margin -0.005)
budget_vs_full_match                  = 0.209
paired B-vs-full LCB                  = -0.00120038 (margin -0.002)
pair_sign_acc_winner_rival            = 0.6395124
paired winner-rival sign LCB          = -0.00181182 (margin -0.005)
effective_query_count                 = 5383.152, unchanged
```

The gate is three scenes short of the required 950/1000 preservation count.

### Failure analysis

1. **The v41 beam was triggered correctly but recovered no scene.**
   - attempted: 53/1000;
   - success: 0/53;
   - remaining failures: 53;
   - mean exact beam evaluations per attempted scene: 1669.585;
   - beam depth: 14/14 on every failure;
   - terminal subsets retained: exactly 12 per failure.

2. **Most beam computation was spent at non-executable cardinalities.**
   - Top-M decision atoms: 30;
   - executable budget atoms: 16;
   - the deletion beam evaluates 14 intermediate levels;
   - after about 1670 exact evaluations it retains only 12 B=16 terminal states;
   - the final layer contains `C(30,16)=145,422,675` possible subsets.
   - Therefore zero recovery is not evidence that the target action is infeasible at B=16; it mainly shows that the terminal coverage of the deletion-tree beam is negligible.

3. **The residual failures are multi-step exchange failures.**
   - mean forced action-flip deletion steps: 6.528;
   - mean preservation-scan evaluations: 306.887;
   - one-swap repair: 0/53;
   - screened two-swap repair: 0/53;
   - a direct executable-layer search must be able to move through several temporarily mismatching B=16 subsets.

4. **The failure is still localized to search, not network query capacity.**
   - all paired quality gates and query-count gates pass;
   - v41 changes only 63/1000 actions relative to MARS;
   - only 5 of the 53 failed-preservation scenes differ from the MARS final action;
   - changing checkpoint, Top-M, B, pair head, or teacher at this point would confound a nearly isolated search failure.

5. **Failure slices are harder in winner-rival sign quality, but this does not justify training yet.**
   - mean winner-rival sign accuracy on failures: 0.5266;
   - mean on preserved scenes: 0.6459;
   - nevertheless the aggregate paired sign gate passes, so first test whether a stronger query-free combinatorial repair can recover the required three scenes.

### Hypothesis

The target action can often be recovered by a sequence of one-out/one-in exchanges at the final B=16 layer even when:

- no direct one-swap restores it;
- no screened two-swap restores it; and
- a width-12 deletion-tree beam misses the necessary terminal subset.

A fixed-budget search should rank each mismatching state by the exact counterfactual deficit of the target action against the action currently selected by the full deployment operator. This gives a useful path signal while every visited state remains directly executable.

### Algorithm changes

New runtime selector alias:

> **CBL-DACC / Counterfactual Budget-Layer DACC**

1. **Disable the v41 deletion-lattice beam in the v42 main configuration.**
   - width = 0, branch = 0, max evaluations = 0;
   - avoids spending evaluations on cardinalities above B=16.

2. **Failure-triggered fixed-budget exchange search.**
   - triggered only after v40 lexicographic deletion, one/two-swap repair, and optional v41 beam all fail;
   - starts from the executable B=16 result;
   - every edge is one-out/one-in and preserves budget/cardinality;
   - performs an exhaustive first one-swap neighborhood (`16 x 14 = 224` for the common 30-to-16 case);
   - later generations use a bounded width/branch search;
   - permits several mismatching intermediate B=16 states before accepting only an exact target-action recovery.

3. **Rival-directed exact recovery key.**
   Mismatching subsets are ranked by:
   - exact deployment action mismatch;
   - target action rank under the exact tournament scores;
   - score deficit against the current selected rival and strongest rival;
   - target-vs-selected-rival margin deficit;
   - full deployment distortion as a tie-breaker.

   This differs from v41, whose recovery potential was dominated by full-score reconstruction and was evaluated mostly before the final budget layer.

4. **Rival-directed mutation proposals.**
   Candidate swaps combine:
   - cheap deployment-graph reconstruction loss;
   - target-vs-current-rival oriented pair contribution gain;
   - global target-vs-rivals contribution gain;
   - proposal-prior gain;
   - deterministic set/action diversity.

5. **Multiple executable seeds.**
   In addition to the v41 B=16 result, bounded seeds are constructed from:
   - global target-support ranking;
   - proposal ranking;
   - support/proposal hybrid;
   - low absolute target-impact ranking.

6. **No-regression replacement rule.**
   - v42 replaces the v41 selected subset only when the exact deployment callback returns the Top-M target action;
   - a merely “closer” but still mismatching subset is never deployed;
   - therefore unsuccessful repair leaves the prior runtime action unchanged.

7. **New diagnostics.**

```text
selector_deployment_coreset_budget_layer_attempted
selector_deployment_coreset_budget_layer_success
selector_deployment_coreset_budget_layer_evaluations
selector_deployment_coreset_budget_layer_iterations
selector_deployment_coreset_budget_layer_peak_width
selector_deployment_coreset_budget_layer_unique_states
selector_deployment_coreset_budget_layer_seed_states
selector_deployment_coreset_budget_layer_best_target_rank
selector_deployment_coreset_budget_layer_best_action_deficit
selector_deployment_coreset_budget_layer_best_margin_deficit
```

### v42 configuration

```yaml
selector_cap_mode: counterfactual_budget_layer_coreset
deployment_coreset_use_deployment_pair_graph: true

deployment_coreset_beam_width: 0
deployment_coreset_beam_branch: 0
deployment_coreset_beam_max_evaluations: 0

deployment_coreset_budget_layer_width: 12
deployment_coreset_budget_layer_branch: 18
deployment_coreset_budget_layer_iterations: 8
deployment_coreset_budget_layer_max_evaluations: 2400
deployment_coreset_budget_layer_exhaustive_first: true
deployment_coreset_budget_layer_seed_count: 4
deployment_coreset_budget_layer_diversity_distance: 4
```

### Modified / added files

- `bdse/planner/selector.py`
- `bdse/planner/nuplan_planner.py`
- `bdse/configs/v42_bdse_cbldacc_fast_cl.yaml`
- `bdse/configs/v42_bdse_cbldacc_fallback_fast_cl.yaml`
- `bdse/configs/v42_bdse_mars_control_fast_cl.yaml`
- `bdse/tools/check_v42_cbldacc_gate.py`
- `bdse/tools/analyze_v42_cbldacc.py`
- `bdse/tests/test_v42_cbldacc.py`
- `run_v42_cbldacc.sh`
- `README_V42_CBLDACC.md`

### Controlled variables

Unchanged:

- v30 checkpoint;
- validation scenarios/order;
- candidate trajectories;
- Top-M evidence universe;
- B=16 query budget;
- neural pair/local outputs;
- final tournament, safety guard, utility refinement and all-flagged guard;
- MARS control;
- gate thresholds.

### Validation completed in the delivery environment

- all Python files compile;
- `bash -n run_v42_cbldacc.sh` passes;
- complete test suite: **124 passed, 5 warnings**;
- new synthetic regression requires three consecutive B-layer swaps:
  - v41-style greedy + one/two-swap repair ends at the wrong action;
  - CBL-DACC traverses two still-mismatching executable subsets;
  - the third exchange restores the target action;
- main/fallback/control configs load and are byte-distinct.

### Runtime validation still required

The delivery environment does not contain the user's nuPlan cache or v30 checkpoint. No claim is made that v42 already passes the 1000-scene gate.

Run and inspect:

```text
selector_deployment_coreset_target_action_preserved
selector_deployment_coreset_budget_layer_attempted
selector_deployment_coreset_budget_layer_success
selector_deployment_coreset_budget_layer_evaluations
selector_deployment_coreset_budget_layer_best_target_rank
selector_deployment_coreset_budget_layer_best_action_deficit
paired teacher_action_match LCB
paired budget_vs_full_match LCB
paired pair_sign_acc_winner_rival LCB
```

### Do not repeat

- Do not enlarge the v41 deletion-tree beam; it already completed all levels and recovered 0/53 while keeping only 12 terminal subsets.
- Do not interpret zero v41 beam success as proof of B=16 infeasibility.
- Do not change checkpoint, Top-M or B in the v42 runtime experiment.
- Do not accept a mismatching subset merely because its target gap is smaller.
- Do not lower the 0.95 preservation threshold.
- Do not run closed loop or finetune before the strict runtime gate passes.
- Do not increase width, branch, iterations and evaluation cap simultaneously in the next iteration; use the new diagnostics to identify which bound is active.

### Next decision rule

- If v42 recovers at least 3 v41 failures, loses zero v41-preserved scenes, and all paired gates pass: proceed to latency measurement, CL20 and CL100.
- If the search succeeds but teacher LCB fails: inspect only the recovered action transitions; do not alter the search before identifying teacher-correct-to-target-wrong changes.
- If `best_target_rank` frequently reaches 1 but exact action remains wrong: the remaining mismatch is likely caused by utility refinement/safety guard rather than raw tournament ranking; next add a guard-aware utility counterfactual diagnostic.
- If `best_target_rank > 1` and the 2400 cap is reached: increase only iterations or branch according to unique-state growth, not all bounds.
- If unique-state growth saturates far below the cap with no recovery: add a larger destroy-repair mutation (3-out/3-in), not another deletion-tree beam.

---

## v43 — SAB-DACC: Stage-Aware Budget-Layer Deployment-Aligned Certificate Coreset

### Date / input

- Input code: user-provided `bdse.zip` containing v42 CBL-DACC.
- Runtime result: user-provided `outputs_v42.zip`, 1000 validation scenarios, frozen v30 checkpoint.
- Only the strict runtime gate was run. No closed-loop or finetuning result is used in this iteration.

### Observed v42 result

v42 improved the actual selector objective enough to satisfy the strict preservation and paired-quality requirements:

```text
selector_deployment_coreset_target_action_preserved = 0.951  (gate floor 0.950)
teacher_action_match                                 = 0.239
paired teacher LCB                                   = -0.0039372  (margin -0.005)
budget_vs_full_match                                 = 0.209
paired B-vs-full LCB                                 = -0.00120038 (margin -0.002)
pair_sign_acc_winner_rival                           = 0.64158287
paired winner-rival LCB                              = -0.000345971 (margin -0.005)
effective_query_count                                = 5383.152
```

CBL-DACC was attempted on 53 scenes and exactly recovered 4, reducing target-action failures from 53 to 49.

### Why the reported gate still failed

The only reported failure was:

```text
selector_deployment_coreset_budget_layer_iterations = 0.4 >= 1
```

This was a checker aggregation error, not an algorithm failure:

- budget-layer recovery is conditionally executed only when the normal selector fails;
- it was attempted on 53/1000 scenes;
- 947 correctly preserved scenes therefore report zero executed recovery iterations;
- among the 53 attempted scenes, conditional mean iterations were 7.547 and the minimum was 1;
- averaging executed iterations over all 1000 scenes produces 0.4 and is not a valid activation check.

The threshold is not changed. v43 checks the configured iteration limit and, when recovery is attempted, verifies the conditional minimum/mean over attempted scenes.

### Residual algorithm diagnosis

The 49 remaining failures reveal a downstream-stage observability problem:

1. In 12/49 failures, `best_target_rank == 1` and raw score deficit is zero.
2. These 12 scenes have no selected-action safety flag and no all-flagged guard activation.
3. The exact deployment evaluator returns final action, post-safety scores and margins, but v42 discards the tournament diagnostics that identify the action before and after utility refinement.
4. Therefore v42 knows that the final action is wrong but ranks the subset as if the target already has zero deficit. Its fixed-budget search loses a recovery gradient precisely when utility refinement overrides the raw tournament winner.
5. This is a theorem/implementation mismatch: the deployment callback is exact for acceptance, but the search-state certificate is not sufficient for the full deployment map.

### Hypothesis

When the target is already the post-safety score winner but utility refinement selects a lower-utility rival, evidence cannot change trajectory utility. It can only recover the target by excluding the rival from the certificate-constrained utility set through one of two exact boundaries:

1. push the rival below the configured score-slack band; or
2. push the rival below the target-relative pair-certificate tolerance.

The minimum distance to these two boundaries is a meaningful recovery certificate for fixed-budget search.

### Algorithm changes

New runtime selector alias:

> **SAB-DACC / Stage-Aware Budget-Layer DACC**

1. **Preserve full deployment diagnostics in the selector callback.**
   - `deployment_evaluator` may now return `(action, scores, margins, diagnostics)`;
   - backward-compatible 3-tuples and dictionary results remain supported;
   - exact evaluation cache stores stage diagnostics without additional model queries.

2. **Stage-aware recovery state.**
   Each fixed-budget state distinguishes:
   - stage 0: final target action already preserved;
   - stage 1: target is not the post-safety score winner;
   - stage 2: target is the post-safety score winner but utility refinement changes the final action.

3. **Utility-boundary recovery certificate.**
   For stage-2 states, the search computes:
   - score-band exclusion distance for the final utility-selected rival;
   - pair-certificate exclusion distance `M[rival,target] + tolerance`;
   - the smaller exact boundary distance as the stage violation.

   This replaces the v42 zero-gradient condition where raw target rank and raw score deficit are both already optimal.

4. **Stage-aware lexicographic beam key.**
   Fixed-budget states are ranked by:
   - exact final-action preservation;
   - exact downstream-stage violation;
   - raw target rank;
   - score and margin deficits;
   - deployment distortion and deterministic diversity.

5. **Rival-directed mutations remain unchanged.**
   The current final rival continues to define oriented target support, so the new stage certificate changes the search objective rather than tuning width, branch, iterations, evaluation cap or thresholds.

6. **No-regression deployment rule remains unchanged.**
   A new subset replaces the prior v42 subset only after the unchanged complete deployment callback returns the exact Top-M target action.

7. **New diagnostics.**

```text
selector_deployment_coreset_budget_layer_iteration_limit
selector_deployment_coreset_budget_layer_best_stage
selector_deployment_coreset_budget_layer_best_stage_violation
selector_deployment_coreset_budget_layer_best_raw_action
```

### Runtime gate acceleration

The old gate path performed:

1. full `read_text().splitlines()` parsing of both JSONL files into dictionaries of complete records;
2. NumPy allocation for each paired metric;
3. a second full candidate JSONL parse in `analyze_v42_cbldacc.py`;
4. two Python process startups.

v43 changes this to:

- aligned-order streaming fast path;
- Welford online mean/variance for the exact same one-sided 95% LCB formula;
- keyed fallback retaining only requested metric scalars when files are not aligned;
- candidate conditional diagnostics and report generation integrated into the gate command;
- `python -S` for the standard-library-only checker, avoiding unrelated site-package startup.

Delivery-environment benchmark on the uploaded 1000-scene files:

| Path | Wall time | Peak RSS |
|---|---:|---:|
| Original v42 gate checker | 2.34 s | 379 MB |
| Original v42 analysis pass | 2.07 s | 334 MB |
| v43 combined gate + analysis | 0.57 s | 18 MB |

The numerical paired results are identical to the original checker.

### Configuration

The search budget/configuration is intentionally unchanged from v42:

```yaml
selector_cap_mode: stage_aware_budget_layer_coreset
deployment_coreset_use_deployment_pair_graph: true
deployment_coreset_beam_width: 0
deployment_coreset_budget_layer_width: 12
deployment_coreset_budget_layer_branch: 18
deployment_coreset_budget_layer_iterations: 8
deployment_coreset_budget_layer_max_evaluations: 2400
deployment_coreset_budget_layer_exhaustive_first: true
deployment_coreset_budget_layer_seed_count: 4
deployment_coreset_budget_layer_diversity_distance: 4
```

### Modified / added files

- `bdse/planner/selector.py`
- `bdse/planner/nuplan_planner.py`
- `bdse/planner/tournament.py`
- `bdse/tools/check_v38_runtime_gate.py`
- `bdse/tools/check_v42_cbldacc_gate.py` (backward-compatible conditional-statistics fix)
- `bdse/tools/check_v43_sabdacc_gate.py`
- `bdse/configs/v43_bdse_sabdacc_fast_cl.yaml`
- `bdse/configs/v43_bdse_sabdacc_fallback_fast_cl.yaml`
- `bdse/configs/v43_bdse_mars_control_fast_cl.yaml`
- `bdse/tests/test_v43_sabdacc.py`
- `run_v43_sabdacc.sh`
- `README_V43_SABDACC.md`

### Controlled variables

Unchanged:

- v30 checkpoint;
- validation scenario set and ordering;
- candidate trajectories;
- Top-M evidence universe;
- B=16 evidence/query budget;
- pair/local network output;
- MARS control;
- safety guard, utility refinement and all-flagged guard;
- all absolute and paired gate thresholds;
- v42 fixed-budget search width, branch, iteration and evaluation limits.

### Validation completed in the delivery environment

- all Python files compile;
- `bash -n run_v43_sabdacc.sh` passes;
- complete test suite: **126 passed, 5 warnings**;
- new synthetic regression reproduces the residual v42 failure mode:
  - target is raw rank 1 in every state;
  - final action is changed only by utility refinement;
  - 3-field deployment feedback gives zero recovery gradient and fails;
  - stage-aware 4-field feedback crosses multiple executable B-layer states and restores the exact target action;
- the fast checker reproduces all original paired means and LCBs on the uploaded results;
- the patched v42 checker directly re-evaluates the uploaded v42 files as PASS using conditional attempted-scene iterations;
- applying corrected conditional semantics to the uploaded v42 result yields a gate pass, because the actual v42 quality requirements were already satisfied.

### Runtime validation still required

Run v43 on the same frozen 1000-scene setup. Do not claim additional algorithm gain until observing:

```text
selector_deployment_coreset_target_action_preserved
selector_deployment_coreset_budget_layer_success
selector_deployment_coreset_budget_layer_best_stage
selector_deployment_coreset_budget_layer_best_stage_violation
previous_failures_recovered
previous_preserved_lost
paired teacher_action_match LCB
paired budget_vs_full_match LCB
paired pair_sign_acc_winner_rival LCB
```

### Do not repeat

- Do not lower the 0.95 preservation threshold; v42 already reaches 0.951.
- Do not require an all-scenario mean conditional-iteration count to exceed one.
- Do not increase beam width, branch, iterations or evaluation cap before testing stage-aware feedback.
- Do not treat raw target rank 1 as final deployment-action preservation when utility refinement is enabled.
- Do not optimize trajectory utility through evidence atoms; utility is fixed candidate geometry. Optimize certificate eligibility boundaries instead.
- Do not parse complete JSONL records into two large dictionaries when only five paired scalars are needed.
- Do not run the separate v42 analysis script after the new combined checker.

### Next decision rule

- If v43 preserves at least the v42 0.951 rate, loses zero v42-preserved scenes, and all paired gates pass: runtime gate is complete; measure selector latency and proceed to CL20/CL100.
- If stage-2 failures are recovered but stage-1 failures remain: keep stage-aware utility logic fixed and next study multi-rival raw tournament feasibility, not utility parameters.
- If `best_stage=2` and `best_stage_violation` reaches approximately zero without exact recovery: inspect top-k eligibility and all-flagged structural-guard diagnostics, because another downstream discrete condition is missing.
- If v43 changes no additional action but all gates pass: retain v43 because it fixes checker correctness and deployment-state sufficiency; do not force a new algorithm change solely to increase version number.

---

## v44 — RADS: Regret-Aware Any-Budget Deployment Supervision

### Motivation from the v43 1000-scenario result

The v43 runtime gate passed, but it did not establish planning-quality gain:

- teacher action match remained approximately 0.239;
- full-interface teacher match remained approximately 0.265;
- winner/rival pair-sign accuracy remained approximately 0.642;
- evidence sufficiency remained approximately 0.071;
- only 4 of 53 stage-aware fixed-budget searches recovered the target action;
- the deployment coreset search increased open-loop wall time from roughly
  1.45 s/scenario for the MARS control to roughly 5.27 s/scenario.

The decisive training issue is upstream of v41-v43 search. The frozen v30
training configuration uses:

```yaml
training:
  epochs: 4
  predicted_selector_start_epoch: 6
```

Epoch indexing starts at zero. Therefore the pair-action objective uses oracle
certificate masks for every v30 epoch, while the predicted selector used at
runtime never receives action-level supervision. The v43 result is consistent
with this mismatch: proposal decisive-rival recall is high, but selected recall,
pair-sign accuracy, action match, and evidence sufficiency remain weak.

### Algorithmic change

v44 replaces per-scene combinatorial deployment repair with **RADS**:

1. **Exact deployment-path supervision.** After one oracle warm-up epoch, the
   action objective uses evidence masks generated by the exact runtime MARS
   selector. Gradients therefore train pair margins on the atoms the deployed
   planner actually selects.

2. **Any-budget action supervision.** Each batch evaluates the runtime selector
   at budgets 8, 16, and 24. Teacher-directed action loss is averaged with
   weights 0.75, 1.5, and 0.75. This yields one checkpoint that is trained for a
   budget curve rather than only B=16 and provides a principled basis for the
   paper's budget sweep.

3. **Robust regret-aware weighting.** For each deployment budget, the selected
   action's teacher regret is divided by a per-scene robust teacher-cost scale,
   transformed with `log1p`, clipped, and detached. The resulting weight
   prioritizes high-consequence deployment failures without allowing the
   heavy-tailed raw teacher cost to dominate training.

4. **Deployment schedule validation.** Training now raises a clear error when
   `predicted_selector_start_epoch >= epochs` while pair-action supervision is
   enabled. Oracle-only selector training must be explicitly marked with
   `allow_oracle_only_selector_training: true`.

5. **Fast runtime retained.** v44 uses the v43 MARS control selector at runtime.
   It does not execute DACC/Lex-DACC/PR-DACC/fixed-budget layer search. The
   deployment goal is amortized learned evidence selection, not expensive
   online subset repair.

### Configuration

```yaml
experiment:
  name: v44_rads
training:
  epochs: 12
  action_loss_start_epoch: 0
  predicted_selector_start_epoch: 1
  deployment_budgets: [8, 16, 24]
  deployment_budget_weights: [0.75, 1.5, 0.75]
  deployment_regret_weight: 1.0
  deployment_regret_clip: 3.0
  deployment_regret_min_scale: 100.0
  pair_action_loss_weight: 4.0
  loss_weights:
    action: 10.0
```

The recommended run warm-starts from the v30 best checkpoint with a lower
learning rate (`6e-6`) and validates all 1000 scenarios every epoch using dense
full-interface diagnostics.

### Modified / added files

- `bdse/model/losses.py`
- `bdse/experiments/train.py`
- `bdse/experiments/evaluate_open_loop.py`
- `bdse/configs/v44_bdse_rads_train.yaml`
- `bdse/configs/v44_bdse_rads_fast_cl.yaml`
- `bdse/configs/v44_bdse_rads_b8_fast_cl.yaml`
- `bdse/configs/v44_bdse_rads_b24_fast_cl.yaml`
- `bdse/tests/test_v44_rads.py`
- `run_v44_rads.sh`
- `README_V44_RADS.md`
- `ALGORITHM_UPDATE_LOG.md`

### Validation completed in the delivery environment

- all modified Python files compile;
- `bash -n run_v44_rads.sh` passes;
- complete test suite: **130 passed, 5 warnings**;
- schedule regression tests confirm that the historical v30-style oracle-only
  schedule is rejected unless explicitly marked as an ablation;
- no nuPlan cache or v30 checkpoint is available in the delivery environment,
  so no empirical v44 gain is claimed.

### Required runtime validation

1. Train v44 from the frozen v30 checkpoint.
2. Evaluate 1000 identical validation scenarios at B=16.
3. Also evaluate B=8 and B=24 using the same checkpoint and scenario order.
4. Compare against frozen v30/MARS and report:
   - teacher action match;
   - median, p90, p95, and CVaR teacher regret;
   - winner/rival and near-tie pair-sign accuracy;
   - proposal and selected decisive-rival recall;
   - evidence sufficiency;
   - wall-clock latency p50/p90/p95 and GPU memory.
5. Run CL20 only if open-loop teacher action match improves by at least two
   absolute percentage points and tail regret does not regress.

### Do not repeat

- Do not spend more runtime on v41-v43 beam/layer search before retraining the
  deployed selector.
- Do not select a checkpoint only by aggregate validation loss; retain
  metric-specific best checkpoints for teacher action match, teacher regret,
  and full-interface action match.
- Do not call the current generic external adapters faithful GameFormer, DTPP,
  PlanTF, PLUTO, or PDM-Closed implementations.
- Do not use mean teacher regret alone; its distribution is strongly
  heavy-tailed.

---

## v45 — PB-RADS: Primary-Budget Exact Deployment Supervision and Mask Distillation

### Empirical diagnosis of the uploaded v44 run

The uploaded `output_v44_rads_fast_2gpu_v2` run does **not** pass the v44
open-loop gate and should not be used as evidence that RADS training improved
the model.

Observed B=16 / 1000-scenario metrics:

| Metric | v44 | frozen v30/MARS control or previous reference | Interpretation |
|---|---:|---:|---|
| teacher action match | 0.246 | 0.238 | +0.008, below the required +0.020 |
| full-interface teacher match | 0.269 | about 0.265 | dense model remains a low ceiling |
| budget-vs-full match | 0.221 | 0.205 | improved, but still low |
| winner/rival pair-sign accuracy | 0.6564 | about 0.6384 | useful improvement |
| evidence sufficiency | 0.0820 | about 0.071 | small absolute gain; median is zero |
| proposal decisive-atom recall | 0.8320 | high | proposal is not the main bottleneck |
| selected decisive-atom recall | 0.3989 | low | fixed-budget allocation remains the bottleneck |
| selected interaction decisive recall | 0.3444 | low | critical interaction evidence is often dropped |
| MARS target-action preservation | 0.944 | 0.951 in prior fixed-budget runs | selector preservation regressed |
| p95 planner latency | 1096.7 ms | deployment target not met | not real-time at the configured replan rate |

The v44 per-sample regret distribution is heavy-tailed: median approximately
26.1, p90 approximately 30.8k, p95 approximately 45.7k, and CVaR90
approximately 52.6k. The frozen control JSONL was not included in the uploaded
archive, so the required median/p90 non-regression condition cannot be verified.

### P0 training-validity failure

Every row of `bdse_v44_rads.train_log.jsonl` has:

```text
loss = NaN
L_cert_frontier = NaN
```

The source is `_certificate_action_gap_loss`. When a scene has hard candidates
but no safe candidate, `best_safe` is a large negative masking sentinel. The
code evaluates `softplus(best_hard - best_safe)` before applying
`frontier_mask=0`; the result is `inf * 0 = NaN`. AMP/GradScaler can then skip
optimizer steps without making the run fail. Therefore the small v44 metric
changes may come from runtime configuration, checkpoint selection noise, or a
partially/fully skipped finetune rather than a clean algorithmic update.

### P0 deployment-supervision mismatch

The v44 README states that epochs 1--11 use exact runtime masks and that each
batch optimizes B=8/16/24. The fast configuration actually uses:

```yaml
deployment_selector_scenes_per_rank: 2  # local batch is 4
deployment_selector_every_n_steps: 2
deployment_budget_strategy: weighted_round_robin
```

Thus exact predicted-selector masks cover about `2/4 * 1/2 = 25%` of local
scene-steps. Weighted round-robin evaluates one budget per rank-step, with B=16
on about half the slots. The primary B=16 exact deployment path therefore
receives only about 12.5% scene-step coverage before the short final exact tail.
The measured epoch metric `selector_exact_fraction=0.25` confirms this mismatch.

### Algorithmic diagnosis

1. **The dense interface is the upstream ceiling.** Full-interface teacher match
   is only 0.269. A perfect budget selector cannot produce theoretical SOTA if
   the complete learned evidence interface still chooses the teacher action in
   only about one quarter of scenes.
2. **Proposal recall is high but selected recall is low.** The 0.832 proposal
   recall versus 0.399 selected recall localizes the current fixed-budget
   failure to within-Top-M allocation and signed-margin preservation, not to
   candidate atom discovery.
3. **Action agreement is not evidence sufficiency.** Budget-vs-full match is
   0.221 while evidence sufficiency is 0.082 with median zero. The selector can
   occasionally reproduce an action without reconstructing or certifying the
   decisive margin. Paper claims must prioritize one-sided decisive-margin
   coverage rather than action agreement alone.
4. **The paper and runtime selector are not the same algorithm.** The paper
   describes uncertainty-aware capped LCB greedy selection with a submodular
   interpretation, while the deployed v44 path is a signed MARS margin coreset
   with swap passes and uncertainty disabled. The theoretical objective,
   implementation, and ablations must be made identical before submission.
5. **Structural safety and decision budget are conflated in reporting.** Hard
   safety is budget-exempt in the implementation. Report structural mandatory
   safety coverage separately from budgeted critical-evidence recall; do not
   call raw selected hard recall a failure when the atom is intentionally in the
   structural channel.
6. **Checkpoint selection was noisy.** Validation used 256 scenes and selected
   by teacher action match, reaching 0.3906 on the small validation subset but
   only 0.246 on the fixed 1000-scene evaluation. This is selection variance,
   not a stable generalization gain.

### v45 changes implemented

1. **Finite certificate losses.** Safety and safe-frontier masks are applied
   before `softplus`, eliminating sentinel overflow and `inf * 0`.
2. **Synchronized fail-fast.** Every scalar loss is checked for finiteness before
   backward. A DDP all-reduce makes every rank abort together on any invalid
   objective.
3. **Primary-plus-aux budget schedule.** B=16 is optimized on every deployment
   step. One auxiliary budget (B=8 or B=24) rotates with the correct aggregate
   any-budget weighting.
4. **Full exact deployment alignment.** The recommended configuration uses all
   local scenes every step after epoch 0 and enforces
   `min_deployment_exact_fraction=1.0` at startup.
5. **Deployment-mask distillation.** Exact stop-gradient MARS masks from the
   active budgets produce a soft selected-frequency target for proposal logits.
   This is the missing direct signal from discrete fixed-budget selection back
   to the learned proposal head; deployment behavior itself is unchanged.
6. **Core-claim checkpointing.** Fixed-budget critical score now includes dense
   full-interface match and effective decisive recall, and treats budget-exempt
   hard safety through effective hard recall. The run uses 1000-scene dense
   validation and saves metric-specific checkpoints.
7. **Strict gate tool.** `check_v45_pb_rads_gate.py` verifies finite training,
   exact selector coverage, +2 point teacher-match gain, median/p90 regret
   non-regression, winner/rival sign gain, material evidence-sufficiency gain,
   and a user-specified p95 latency target.
8. **Optional base normalization support.** Code supports per-scene normalized
   base-cost regression, but it is disabled in the first v45 run to keep the
   validity-controlled comparison isolated. Enable it only as a separate
   ablation after v45.

### Modified / added files

- `bdse/model/losses.py`
- `bdse/experiments/train.py`
- `bdse/configs/v45_bdse_pb_rads_train_exact_2gpu.yaml`
- `bdse/configs/v45_bdse_pb_rads_fast_cl.yaml`
- `bdse/configs/v45_bdse_pb_rads_b8_fast_cl.yaml`
- `bdse/configs/v45_bdse_pb_rads_b24_fast_cl.yaml`
- `bdse/tools/check_v45_pb_rads_gate.py`
- `bdse/tests/test_v45_pb_rads.py`
- `run_v45_pb_rads.sh`
- `README_V45_PB_RADS.md`
- `ALGORITHM_UPDATE_LOG.md`

### Validation completed in the delivery environment

- all Python files compile;
- `bash -n run_v45_pb_rads.sh` passes;
- complete test suite: **142 passed, 5 warnings**;
- a regression test reproduces the all-hard/no-safe v44 NaN case and confirms
  finite certificate losses;
- schedule tests reject the v44 25% exact-supervision configuration when the
  v45 100% floor is requested;
- primary-plus-aux tests confirm B=16 is present on every rank-step and B=8/B=24
  are balanced across the deterministic schedule.

### Required next experiment

Warm-start from the frozen v30 checkpoint, not the v44 checkpoint. The v44
checkpoint cannot be trusted because the optimization objective was non-finite.
Use the exact command in `README_V45_PB_RADS.md`, then run the strict gate against
the same frozen v30/MARS 1000-scenario JSON/JSONL.

### Next decision rule

- **If v45 passes:** run paired CL20 on exactly the same scenario tokens as the
  control. Proceed to CL100 only if safety is non-inferior and the primary
  closed-loop score improves.
- **If full-interface match rises but budgeted match/sufficiency does not:** the
  next algorithm should replace independent signed coreset selection with one
  nested, anytime one-sided certificate ordering; do not tune quotas or add
  another online repair search.
- **If full-interface match remains below 0.30:** stop changing the selector.
  Improve pair-margin representation with hard-rival mining, antisymmetric
  cycle consistency, and teacher-cost calibration first.
- **If latency remains above 500 ms p95:** profile proposal construction,
  pair-score materialization, CPU selector transfer, and utility refinement.
  Do not claim real-time planning from two-GPU shard wall time.

### CCF-A novelty path after a valid v45 result

The strongest theory-aligned extension is an **anytime one-sided adverse-bound
certificate coreset**. For each predicted winner--rival pair, assign every
unqueried atom a calibrated adverse contribution bound. Querying an atom removes
that worst-case penalty and replaces it with its observed lower-confidence
margin contribution. Capped reduction of certificate deficit is monotone
submodular under a knapsack budget, yielding a standard greedy approximation
bound and a single nested ordering valid for every budget. This directly serves
the paper's central idea and avoids another ad-hoc quota/search variant. It
should be implemented only after v45 establishes that the learned dense margin
interface is accurate enough to support such a guarantee.

### Do not repeat

- Do not continue from the v44 checkpoint.
- Do not interpret v44's +0.8 point match change as a trained-model gain.
- Do not use 256-scene validation to select the final checkpoint.
- Do not spend more compute on beam/layer/DACC repair or quota sweeps.
- Do not increase B or Top-M to hide low evidence sufficiency.
- Do not report two-GPU shard throughput as per-replan latency.
- Do not claim a submodular/uncertainty selector theorem while deploying MARS
  with uncertainty disabled.

---

## v45-fast — GPU Margin-Damage Training Surrogate with Sampled Exact Distillation

### Trigger

The full-exact v45 training command required almost one day for five epochs on
2xA30 with a Xeon Gold 5220R. The DDP topology was correct; profiling the code
showed that each rank synchronously executed the CPU/NumPy runtime selector for
all four local scenes and two budgets on every optimizer step.

### Root cause

- `_predicted_pair_certificate_masks()` calls `.detach().cpu().numpy()` on the
  pair-margin field and proposal state, forcing a GPU synchronization.
- The signed MARS coreset then performs backward elimination in Python/NumPy.
- `primary_plus_aux` repeats the full conversion, Top-M construction, and search
  for B=16 plus B=8/B=24.
- At global batch eight and 50k scenarios there are approximately 6250 steps per
  epoch. A synthetic v45-sized batch measured about 0.57 s for one exact budget
  on four scenes; two budgets therefore consume more than one second per rank
  per step before forward/backward.
- DDP amplifies this CPU imbalance because gradient synchronization cannot begin
  until both ranks finish their local selector.
- 1000-scene validation every two epochs with dense diagnostics performs an
  additional dense inference and adds avoidable wall time.

### Changes

1. Added `training.deployment_selector_backend=hybrid_fast`.
2. Added a GPU margin-damage surrogate that computes all configured budgets in
   one nested ranking. Its atom score approximates exact MARS removal damage
   using signed-margin residual, sign mismatch, winner protection, and predicted
   action preservation.
3. Exact runtime masks remain the target for `L_deploy_select`, sampled using
   `deployment_exact_distill_scenes_per_rank` and
   `deployment_exact_distill_every_n_steps`.
4. Added surrogate/exact Jaccard agreement and separate fast/exact selector wall
   times to the train log.
5. Added per-stage epoch timing for data wait, host-to-device transfer, forward,
   loss construction, and backward/optimizer step.
6. Added a fast training configuration and launcher with reduced intermediate
   validation and checkpoint I/O. Final 1000-scene open-loop evaluation remains
   unchanged.
7. Added a synthetic selector benchmark and regression tests for nested masks,
   budget compliance, and fast-backend schedule validation.

### Validation

- Complete suite: **144 passed, 5 warnings**.
- Synthetic CPU benchmark at B=4, K=32, E=128, P=192:
  - exact full local batch, one budget: about 0.57 s;
  - exact one-scene distillation: about 0.137 s;
  - fast all-scene B=8+B=16 masks: about 0.006 s.
- With one exact scene every four steps, the selector-only path is reduced by
  roughly an order of magnitude or more; end-to-end speedup depends on model,
  cache storage, and validation overhead.

### Scientific constraint

Runtime/open-loop/closed-loop evaluation still uses the exact deployed MARS
selector. The GPU surrogate is only a structured training approximation. Final
results must include a smaller exact-all-scenes ablation and report the exact
mask sampling rate plus surrogate/exact agreement.

### Do not repeat

- Do not set all-scene exact CPU selection for every budget on every training
  step merely to claim deployment alignment.
- Do not interpret low GPU utilization as a DDP failure before checking
  `selector_exact_wall_time_s` and `train_loss_ms_per_step`.
- Do not enable dense 1000-scene validation every two epochs during exploratory
  training; retain it for final evaluation and selected checkpoints.

---

## v46 result audit and v47 D3CE — Deployment-Consistent Calibrated Critical Evidence

### Trigger

The exact two-GPU v46 AOCC run completed with finite losses and
`selector_exact_fraction=1.0`, but the open-loop gate still failed. Uploaded
1000-scenario results were audited together with full validation diagnostics,
a partial test diagnostic build, and 1000-scenario per-city training diagnostics.

### v46 measured result

- teacher action match: **0.226**;
- evidence sufficiency: **0.080087**;
- dense full-interface action match: **0.298**;
- pair-full exact-tournament action match: **0.237**;
- budget vs pair-full match: **0.823**;
- dense winner/rival sign accuracy: **0.8076**;
- pair-head winner/rival sign accuracy: **0.5738**;
- dense near-tie sign accuracy: **0.6481**;
- pair-head near-tie sign accuracy: **0.3663**;
- proposal decisive recall: **0.8320**;
- selected decisive recall: **0.5287**;
- AOCC certified-pair fraction: **0.0867**;
- p95 single-scenario planner latency: **867.09 ms**;
- mean prediction stage: **567.26 ms**;
- mean selector stage: **3.04 ms**;
- mean tournament stage: **7.27 ms**.

### Status of the three v45 failure causes

1. **Exact runtime-selector alignment: solved operationally.** Every post-warmup
   epoch reports exact fraction 1.0. This removes the v45 6.25% coverage defect.
2. **Upstream pair/dense interface: not solved.** Dense full match changed only
   from 0.296 to 0.298, while the deployment pair-full path is lower at 0.237.
   The independent pair head is especially weak on near ties.
3. **Budget compression: only partially solved relative to the wrong target.**
   AOCC preserves pair-full actions fairly often, but the pair-full target itself
   is frequently wrong. Dense-to-pair-full loses 154 correct scenes and rescues
   93; pair-full-to-budget loses 18 and rescues 7; dense-to-budget loses 164 and
   rescues 92. End-to-end harmful compression therefore did not improve.

### Additional root causes

- The AOCC target was selected by an internal pairwise preference proxy rather
  than the exact final tournament including utility and safety guards.
- The raw base-cost loss remained around 2,400 with a 0.35 weight, dominating
  normalized action/critical-evidence losses. `normalize_base_loss` was false.
- `action_conditioned_action_loss_weight` was zero, despite the dense/local head
  being much more accurate than the independent pair head.
- The AOCC mean target confidence was only about 0.05 and only 8.7% of target
  pairs were certified at B=16. Fallback was disabled, so uncertified actions
  were used as ordinary decisions.
- Prediction accounts for roughly 90% of end-to-end latency; further selector
  micro-optimization alone cannot meet a 500 ms p95 target.
- v46 reported `aocc_bound_calibrated=1` even though no independent calibration
  run or provenance existed. The flag was implementation-derived, not evidence
  of a valid held-out calibration protocol.

### Dataset audit

Validation oracle capacity is high: full-interface match **0.9657**, B=16 oracle
sufficiency **0.9120**, runtime teacher match **0.7490**. Therefore the main val
bottleneck is learned representation/decision alignment, not evidence-bank
capacity.

The partial test cache is not preprocessing-compatible with validation:

- drivable polygon count: **0.0** test vs **31.74** val;
- safe candidate exists: **0.4937** vs **0.7173**;
- B=16 oracle sufficiency: **0.8065** vs **0.9120**;
- route-distance p95-p90: **20.66 m** vs **3.26 m**.

No final test claim is allowed until the complete test cache passes the new
split-parity gate.

### v47 algorithm changes

1. **Exact-tournament AOCC target.** AOCC receives the full Top-M action produced
   by the exact deployment tournament, rival graph, safety filter, utility
   refinement and all-flagged guard. The proxy Copeland target is no longer used
   when the planner can provide an exact target.
2. **Teacher-targeted exact selector training.** Stop-gradient AOCC masks use the
   teacher action during training, so the selector is taught evidence that
   protects the desired action rather than its current mistaken winner.
3. **Integrable local margin plus sparse residual.** The action-conditioned head
   defines the margin for every pair. The antisymmetric pair head learns only a
   residual and is evaluated at runtime on at most 48 boundary/safety/winner
   pairs; unrefined pairs remain valid local margins.
4. **Counterfactual critical-evidence loss.** Current teacher-vs-hard-rival pairs
   define a cost-normalized distribution over atoms with positive teacher-margin
   support. Pair residual and proposal logits receive listwise supervision on
   that distribution.
5. **Loss-scale correction.** Enable normalized base regression, nonzero
   action-conditioned action loss and stronger normalized full-action,
   hard-rival, deployment-selection and critical-evidence objectives.
6. **Honest calibration provenance.** The calibrated flag requires a
   group-disjoint calibration-only provenance JSON. A hand-set epsilon and
   learned variance no longer imply calibration.
7. **Group-disjoint validation protocol.** Added deterministic log-level
   `val_tune`/`val_calib` manifests. Checkpoints and hyperparameters use
   `val_tune`; one-sided calibration uses `val_calib`; test remains untouched.
8. **Uncertified fallback.** Closed-loop config can trigger a same-budget rival
   expansion/fallback when the AOCC certified-pair fraction is below the
   configured floor.
9. **Error-decomposition metrics.** Evaluator now reports pair-interface flips,
   harmful/beneficial pair compression, harmful/beneficial pair-interface
   changes, fully certified scene rate, and conditional teacher match.
10. **Dataset parity gate.** Added a diagnostic checker for map-feature,
    safe-candidate, oracle-capacity and route-tail drift before final test use.

### Motivation and definition decisions

- The seven existing macro-action labels are retained. Validation oracle capacity
  shows that replacing the maneuver taxonomy is not the current limiting factor.
  A new taxonomy now would confound the fixed-budget evidence contribution.
- Existing evidence families are retained because proposal decisive recall is
  already high and B=16 oracle sufficiency exceeds 0.91 on validation. The model
  must learn *which* atoms change teacher-vs-rival decisions, not merely emit more
  atom types.
- Candidate generation remains a separate error component. Test safe-candidate
  failure and missing map polygons must be fixed in preprocessing/candidate
  coverage before claiming model or selector gains.

### Added / modified files

- `bdse/configs/v47_bdse_d3ce_train_2gpu.yaml`
- `bdse/configs/v47_bdse_d3ce_cl.yaml`
- `bdse/model/bdse_model.py`
- `bdse/model/losses.py`
- `bdse/planner/selector.py`
- `bdse/planner/nuplan_planner.py`
- `bdse/experiments/evaluate_open_loop.py`
- `bdse/tools/build_group_disjoint_calibration_split.py`
- `bdse/tools/calibrate_v47_adverse_bounds.py`
- `bdse/tools/apply_v47_calibration.py`
- `bdse/tools/check_v47_d3ce_gate.py`
- `bdse/tools/check_dataset_diagnostics_parity.py`
- `bdse/tests/test_v47_d3ce.py`
- `run_v47_d3ce.sh`
- `NEXT_COMMANDS_V47_D3CE.sh`
- `README_V47_D3CE.md`

### Validation completed

- complete unit suite: **154 passed, 5 warnings**;
- Python compile check: pass;
- `bash -n run_v47_d3ce.sh`: pass;
- `bash -n NEXT_COMMANDS_V47_D3CE.sh`: pass;
- uploaded partial test diagnostics correctly fail the new parity gate.

### Required experiment order

1. Build group-disjoint `val_tune` and `val_calib` manifests.
2. Retrain from the frozen v30 checkpoint using only `val_tune` for selection.
3. Calibrate adverse residuals only on `val_calib` with provenance.
4. Replay v47 and frozen control on identical `val_tune` rows.
5. Run strict token-paired gate; proceed to CL20 only after PASS.
6. Complete and repair test preprocessing, pass parity gate, then evaluate test
   once as final evidence.

### CCF-A claim boundary

The defensible core contribution is a deployment-identical, calibrated, nested
fixed-budget critical-evidence selector with a three-term error decomposition:
candidate coverage, full-interface decision error, and budget-compression error.
The one-sided certificate preserves the learned full-interface action under its
calibration assumptions; it does not make a wrong full-interface action correct.
The paper must report certificate coverage, conditional action preservation,
budget curves, scenario/city slices, latency stages, and candidate oracle bounds.

---

## v48 DBCE — Deployment-Boundary Critical Evidence (2026-07-27)

### Why v47 did not enter closed loop

The v47 pipeline stopped intentionally at the strict paired open-loop gate.  The
closed-loop directory is empty because the gate command returned nonzero under
`set -e`; this was not a nuPlan simulator startup failure.  The uploaded run had:

- teacher action match `0.249` versus control `0.238`, a `+0.011` gain below the
  required `+0.020`;
- evidence sufficiency `0.073575` versus `0.070400`, a `+0.003175` gain below
  the required `+0.010`;
- pair-full deployment match `0.248 < 0.300`;
- certified target-pair fraction `0.135 < 0.500` and fully certified scene rate
  `0.028`;
- planner p95 latency `1365.15 ms > 500 ms`;
- paired regret regression at both median and p90.

A second experiment-integrity issue was discovered: two launcher logs began
about two minutes apart and the training JSONL contains two rows for every epoch
(24 rows for 12 unique epochs).  These independent jobs wrote to the same output
root.  V47 remains useful for diagnosis, but it is not a clean paper-grade run.

### What v47 learned and what it did not

**Effective components**

1. Exact-selector supervision reached `1.0` after epoch zero.
2. Full-interface match improved from `0.265` to `0.319`.
3. Winner/rival pair sign accuracy improved from `0.638` to `0.692`.
4. Actual sparse query count fell from about `11252` to `2285` per scenario.
5. Budget-to-pair-full preservation reached `0.895`; pair-to-budget harmful
   compression was only `0.018`.

**Ineffective or misleading components**

1. Near-tie pair sign accuracy fell from `0.583` to `0.469`; the residual head
   learned broad corrections but damaged the decision boundary.
2. `L_cf_critical_pair` remained essentially flat (`3.612 -> 3.610`).  The v47
   target rewarded all positive teacher support, not the counterfactual effect
   of removing an atom from the teacher/rival boundary.
3. Proposal loss decreased, but `proposal_top_m=64` covered essentially the
   entire average decision evidence pool (`~29.97` atoms); proposal ranking had
   no deployment consequence.
4. `min_soft_interaction_topm_slots=24` caused about `15.30 / 15.87 = 96.4%` of
   the decision budget to be filled by interaction-family evidence.  High recall
   therefore did not imply causal decision support.
5. AOCC protected the pair-full action well, but the pair-full action itself was
   correct only `0.248` of the time.  Dense-to-pair interface error, not final
   budget compression, remained the dominant action-loss source.
6. The per-atom prior radius `0.10` was roughly five times the observed raw
   atom-pair MAE and accumulated across omitted atoms.  B=16 therefore certified
   only a small fraction even though the full-order target was usually
   certifiable.

### v48 core algorithm changes

1. **Leave-one-out deployment-boundary criticality.**  For teacher action `w`,
   rival `r`, full teacher margin `m_wr`, and atom support `d_i`, the target is

   `relu(gamma - (m_wr - d_i)) - relu(gamma - m_wr)`.

   This is nonzero only when removing the atom increases the boundary deficit.
   It is divided by query cost and used as the shared listwise target for the
   pair residual and proposal heads.
2. **Teacher-nearest + model-confused rival mining.**  Critical evidence is
   learned against the union of teacher-nearest rivals and current model errors,
   rather than predicted-hard rivals alone.
3. **Confidence-shrunk integrable pair interface.**  Runtime margins use the
   integrable local action-conditioned margin plus a sparse antisymmetric
   residual.  The combined margin is shrunk back toward the local interface when
   residual variance is high or signs disagree.  V47 skipped this calibration in
   residual mode.
4. **Tournament-active AOCC frontier.**  AOCC protects near-boundary target
   rivals and safety-crossing rivals instead of requiring every target-incident
   pair.  It reports original frontier size and retained pair-weight fraction.
5. **Real proposal competition.**  `proposal_top_m` is reduced `64 -> 24`, while
   reserved interaction slots are reduced `24 -> 8`.  Interaction evidence must
   now compete with route, progress, regularity, and other decision families.
6. **Less over-conservative bounds.**  Calibration prior radius is reduced
   `0.10 -> 0.02`, protected target rivals `16 -> 6`, and calibration remains
   group-disjoint and provenance-gated.
7. **Boundary-aligned checkpointing.**  Best-checkpoint selection now emphasizes
   teacher match, exact/sparse pair-full match, near-tie sign, budget-to-pair
   preservation, sufficiency, regret, and safety.  Raw interaction recall has
   only a small diagnostic weight.
8. **Latency-oriented caps.**  Pair residual refinement is reduced `48 -> 32`,
   selector pairs `128 -> 96`, runtime pair queries `320 -> 192`, tournament
   rivals `16 -> 12`, and utility refinement `12 -> 8`.
9. **Experiment single-writer enforcement.**  Both the run script and full
   pipeline create PID-bearing lock directories.  A second writer to the same
   `OUT_ROOT` fails immediately.
10. **Stricter gate.**  The gate now rejects duplicate epochs, near-tie
    regression, interaction-budget saturation, excessive fallback, inadequate
    AOCC frontier weight, weak certificate coverage, pair-full error, regret
    regression, and latency failure.
11. **Automatic gated CL20.**  The prior command file contained only a commented
    closed-loop example.  V48 starts CL20 automatically after PASS when
    `RUN_CLOSED_LOOP_AFTER_GATE=1` and `NUPLAN_ROOT` is set.

### Configuration changes

- new train config: `bdse/configs/v48_bdse_dbce_train_2gpu.yaml`;
- new closed-loop config: `bdse/configs/v48_bdse_dbce_cl.yaml`;
- training epochs: `12 -> 16`;
- counterfactual rivals: `3 -> 4`;
- counterfactual pair/proposal weights: `4/3 -> 8/4`;
- old non-causal critical pair/proposal weights: `8/2 -> 2/0.5`;
- online hard-rival weight: `3 -> 5`;
- full-action weight: `4 -> 6`;
- pair calibration enabled for the local+residual interface.

### Files added or modified

- `bdse/model/losses.py`
- `bdse/model/bdse_model.py`
- `bdse/planner/selector.py`
- `bdse/experiments/train.py`
- `bdse/configs/v48_bdse_dbce_train_2gpu.yaml`
- `bdse/configs/v48_bdse_dbce_cl.yaml`
- `bdse/tools/calibrate_v48_adverse_bounds.py`
- `bdse/tools/apply_v48_calibration.py`
- `bdse/tools/check_v48_dbce_gate.py`
- `bdse/tests/test_v47_d3ce.py`
- `bdse/tests/test_v46_aocc.py`
- `run_v48_dbce.sh`
- `V48_DBCE_NEXT_COMMANDS.sh`
- `README_V48_DBCE.md`

### Validation completed

- Python compile check: pass;
- `bash -n run_v48_dbce.sh`: pass;
- `bash -n V48_DBCE_NEXT_COMMANDS.sh`: pass;
- complete unit suite: **158 passed, 5 warnings**;
- v48 strict gate replayed on v47 and correctly detected every original failure,
  the near-tie regression, interaction saturation, and all duplicate epochs.

### Claim boundary

V48 is a code-level and objective-level correction, not an assertion that the
new training run will necessarily pass.  The strongest defensible contribution
is the combination of deployment-boundary leave-one-out criticality, an
integrable local margin with calibrated sparse residuals, and a nested
fixed-budget deployment certificate.  Statistical claims remain conditional on
log-disjoint calibration and exchangeability; teacher-action correctness also
depends on candidate coverage and full-interface representation quality.

---

# v50 DBAP-RI — Deployment-aligned Residual Intervention

## Result trigger

v49 failed the strict open-loop gate. The decisive failure moved to the pair interface:

- teacher action match 0.232 vs control 0.286;
- near-tie sign 0.462 vs control 0.593;
- pair-full action match 0.231;
- dense-to-pair-full flip rate 0.692;
- harmful dense-to-pair intervention 0.176 vs beneficial 0.047;
- pair-full-to-budget harmful compression only 0.009;
- p95 latency 854.84 ms.

AOCC certification, fallback control, nested budget fill, and final compression remained effective. v50 therefore preserves those components and fixes the local-to-pair residual interface.

## Algorithm changes

1. Added a shared deployment residual gate in `bdse/model/residual_gate.py`.
   - NumPy runtime and Torch training use the same trust equation.
   - Trust uses variance, boundary strength, raw local/residual sign disagreement, and magnitude ratio.

2. Added pair-level aggregate residual intervention control.
   - Multiple small atom residuals can no longer accumulate into an unconfident pair-sign flip.
   - Unconfident flips are sign-preserving capped.
   - A flip is allowed only when the residual lower-confidence correction exceeds the local margin plus a configurable flip margin.

3. Changed pair residual learning from full reconstruction to correction-focused learning.
   - Local-sign errors receive the largest residual regression weight.
   - Teacher/local near-boundary pairs receive elevated weight.
   - Already-correct, far-from-boundary pairs receive only a small background weight.
   - All action/rank/certificate losses use the exact deployment-gated interface.

4. Added local-only pair-full decomposition.
   - `local_pair_full_interface_action_match`
   - `local_pair_full_to_residual_flip_rate`
   - `harmful_residual_intervention_rate`
   - `beneficial_residual_intervention_rate`
   - `dense_to_local_pair_full_flip_rate`

5. Reworked checkpoint selection.
   - Rewards local pair-full and residual-combined pair-full.
   - Penalizes residual interface drop and net harmful residual intervention.
   - Missing local/residual diagnostics are treated as a failed diagnostic path.

6. Added validation-aware early stopping.
   - Default patience: 3 validation events.
   - Prevents prolonged residual fine-tuning from overwriting a stronger early local interface.

7. Tightened genuine cross-family budget competition.
   - maximum interaction prefix fraction 0.80 -> 0.75;
   - soft interaction Top-M reserve 4 -> 2;
   - decision family boost 0.10 -> 0.0.

8. Retained effective downstream modules.
   - nested AOCC frontier;
   - independent calibration;
   - exact-budget action preservation;
   - candidate/interface/compression error decomposition;
   - teacher-nearest + model-confused rival union.

## Runtime changes

- max runtime pair queries: 128 -> 96;
- max selector pairs: 64 -> 56;
- tournament `L_infer`: 10 -> 8;
- residual refinement pairs: 24 -> 16;
- utility refinement top-k: 6 -> 4;
- exact decision prefix is force-filled to B=16.

## Test-set protocol changes

1. Added `bdse/tools/check_test_set_readiness.py`.
2. Build integrity is now separate from distribution parity.
3. Hard checks include:
   - config parity with val;
   - missing labels and duplicate identity;
   - test/train and test/val manifest overlap when caches are supplied;
   - failed-preprocess fraction;
   - minimum preliminary sample count.
4. An incomplete cache may return `PRELIMINARY_PASS`, but cannot be reported as the final paper test.
5. Natural val-to-test distribution shift is a warning and must not be tuned away.

## New configs and scripts

- `bdse/configs/v50_bdse_dbap_ri_train_2gpu.yaml`
- `bdse/configs/v50_bdse_dbap_ri_cl.yaml`
- `bdse/tools/check_v50_dbap_ri_gate.py`
- `bdse/tools/check_test_set_readiness.py`
- `run_v50_dbap_ri.sh`
- `V50_DBAP_RI_NEXT_COMMANDS.sh`
- `NEXT_COMMANDS_V50_DBAP_RI.txt`
- `BUILD_MATCHED_TEST_SET.sh`
- `CHECK_PARTIAL_TEST_SET.sh`

## Validation

- compileall: passed;
- YAML loading: passed;
- shell syntax: passed;
- tests: 164 passed, 5 warnings.

No v50 performance claim is made before a fresh two-A30 train/calibrate/paired-gate run. Closed-loop remains strictly gated.

---

# v50-FR — Rebuilt Foundation and Exact-Selector Execution Acceleration

## Trigger

The historical warm-start checkpoint `outputs_v30/train/bdse_v30_pmvrbsr.best.pt` was deleted. The v50 launcher therefore could not start, and direct random initialization would have changed the comparison protocol relative to the previous v49/v50 experiments. The exact CPU selector was also the dominant training wall-time bottleneck.

## Experimental-protocol decision

1. Rebuild a v30-compatible foundation checkpoint from random initialization with the current code and the original v30 objective schedule.
2. Warm-start v50 from the rebuilt best checkpoint.
3. Use the exact same rebuilt checkpoint as the frozen control.
4. Recompute control, calibration, paired replay and gate outputs; never reuse historical control/calibration files.
5. Treat historical v49/v50 metrics as diagnostic only. Absolute cross-run comparison is invalid when the foundation checkpoint differs.
6. Direct v50 scratch training remains an explicit ablation, not the primary experiment.

## Foundation rebuild

Added:

- `bdse/configs/v50_rebuild_v30_from_scratch_2gpu.yaml`;
- `RUN_MODE=foundation` in `run_v50_dbap_ri.sh`;
- automatic rebuild in `V50_DBAP_RI_NEXT_COMMANDS.sh` when `V30_CKPT_IN` is absent;
- mid-epoch resume discovery for the foundation stage;
- `bdse/tools/write_checkpoint_provenance.py`;
- SHA-256/config/cache-manifest provenance at `OUT_ROOT/provenance/foundation_checkpoint.json`.

The rebuilt foundation uses the v30 objective for four epochs, seed 17 by default, two-GPU DDP and `teacher_action_match` checkpoint selection. `allow_oracle_only_selector_training=true` is explicit because the original v30 predicted-selector start is after the foundation epoch count.

## Training hot-path diagnosis

The main bottleneck is exact selector execution within the loss:

- packed CUDA-to-CPU synchronization;
- per-scene Python/NumPy HAB and AOCC logic;
- primary-plus-auxiliary exact budgets;
- DDP waits for both ranks before backward synchronization.

At 50k scenarios and global batch eight there are approximately 6,250 optimizer steps per epoch. Data loading, validation and checkpoint I/O are secondary but measurable through existing per-stage metrics.

## Logic-preserving acceleration

Added an optional exact-selector CPU backend:

```yaml
training:
  deployment_selector_cpu_backend: process
  deployment_selector_cpu_workers: 4
```

Implementation details:

- persistent `ProcessPoolExecutor` per DDP rank;
- `spawn` multiprocessing context to avoid forking an initialized CUDA process;
- one NumPy snapshot per rank/step;
- independent scenes distributed to CPU workers;
- unchanged exact `_predicted_pair_certificate_masks` in every worker;
- deterministic reassembly by scene index;
- one host-to-device mask transfer after all scene results return;
- sequential and thread backends retained for debugging/fallback.

Representative B=4, K=32, E=128, P=56, B16+B8 benchmark:

- sequential steady state: 1.679 s;
- four spawn workers steady state: 0.428 s;
- speedup: 3.92x;
- masks: exactly equal.

The first process invocation includes approximately eight seconds of one-time spawn/import cost. A two-rank nested process-pool smoke test passed.

## Additional execution-only changes

- fused AdamW on supported CUDA builds, with standard fallback;
- foreach gradient clipping, with standard fallback;
- explicit DataLoader workers/prefetch/pinned memory;
- checkpoint interval 2,000 steps;
- foundation and v50 mid-epoch resume;
- included `tools/benchmark_v50_training_hotpath.py`.

The exact selector cadence, exact-scene coverage, budget schedule, losses, validation protocol, calibration and gate were not changed.

## Validation

- compile: passed;
- shell syntax: passed;
- YAML load: passed;
- full unit suite: **165 passed, 5 warnings**;
- exact sequential/process equality: passed;
- two-rank process-pool smoke test: passed.

## Claim boundary

The rebuilt foundation preserves attribution only inside the new matched experiment family. It is not the deleted historical checkpoint and must not be used for direct absolute comparison with old v49/v50 numbers. Component-level v49-versus-v50 claims require variants initialized from the same rebuilt foundation and evaluated on identical rows with identical calibration provenance.

---

# v50.1 — Checkpoint-Independent Foundation Resolution

## Trigger

The server still reported:

```text
Missing checkpoint: outputs_v30/train/bdse_v30_pmvrbsr.best.pt
```

after the historical `outputs_v30` directory had been deleted. The root cause was an engineering dependency retained in both launchers: an unset `V30_CKPT_IN` was immediately repopulated with the deleted hard-coded path. A stale or detached launcher could therefore continue to fail before the intended rebuild protocol became visible.

## Experimental-protocol decision

The paper main run no longer depends on a directory named `outputs_v30`.

The canonical initialization is now a **matched foundation checkpoint**, resolved in this order under `FOUNDATION_POLICY=auto`:

1. an explicitly supplied existing `FOUNDATION_CKPT`;
2. a current-run rebuilt foundation under `OUT_ROOT/foundation_v30_compatible`;
3. a conservatively verified retained copy whose own filename/config/output metadata identifies it as v30-compatible;
4. a fresh rebuild from random initialization using `v50_rebuild_v30_from_scratch_2gpu.yaml`.

Later AOCC/D3CE/DBCE/DBAP checkpoints are rejected by default. They already contain algorithm-specific adaptation and would confound attribution of v50 gains. They may only be enabled with `ALLOW_ALGORITHM_CHECKPOINT_INIT=1`, which is explicitly classified as a transfer-initialization ablation rather than the paper main run.

## Engineering changes

1. Removed the default assignment:

   ```bash
   V30_CKPT_IN=outputs_v30/train/bdse_v30_pmvrbsr.best.pt
   ```

   from the v50 outer and inner launchers.

2. Added canonical variables:

   - `FOUNDATION_CKPT`;
   - `FOUNDATION_POLICY=auto|rebuild|recover|explicit`;
   - `FOUNDATION_SEARCH_ROOT`;
   - `RECOVER_SAFE_FOUNDATION_COPIES`;
   - `ALLOW_ALGORITHM_CHECKPOINT_INIT`.

3. Added `bdse.tools.resolve_foundation_checkpoint`:

   - inventories retained `.pt` files under `outputs_v40*` through `outputs_v50*`;
   - loads each checkpoint safely on CPU;
   - measures current-model key and parameter-shape compatibility;
   - records checkpoint config/output/warm-start metadata;
   - selects only checkpoints with strong v30 identity evidence by default;
   - writes `OUT_ROOT/provenance/foundation_checkpoint_inventory.json`;
   - reports but rejects algorithm-specific checkpoints.

4. The resolved foundation is assigned to both:

   - v50 warm-start;
   - the frozen matched control.

   Control, calibration, replay and gate outputs are therefore recomputed within one provenance family.

5. Added a launcher version banner and changed relative-path resolution to the script directory. This exposes stale server copies immediately in logs.

6. Replaced hard-coded `GPUS=0,1` in downstream stages with the caller-provided `GPUS` value.

7. Added a foundation final-checkpoint fallback if a clean foundation run emits the final checkpoint but no metric-specific `.best.pt` file.

8. Changed the v50 config's `warm_start_recommended` field from a deleted physical path to `resolved_by_V50_DBAP_RI_NEXT_COMMANDS.sh`.

## Recommended interpretation of retained v40-v49 outputs

- A checkpoint whose own metadata identifies it as `bdse_v30_pmvrbsr` may recover the deleted foundation without changing the historical initialization family.
- Directories named `runtime_v30ckpt` often contain evaluation artifacts rather than a copied checkpoint; directory naming alone is not accepted as provenance.
- `outputs_v47_control_val_tune` normally contains control replay outputs, not necessarily model weights.
- v47/v48/v49 trained best checkpoints may be useful as transfer ablations, but not as the main v50 foundation.
- If no verified v30 copy exists, rebuilding a matched foundation is the clean default.

## Validation

- launcher shell syntax: passed;
- resolver unit tests: passed;
- safe v30 identity selection: passed;
- algorithm-specific checkpoint rejection: passed;
- no hard-coded v30 dependency remains in the v50 launch path.

## Claim boundary

A fresh rebuilt foundation does not recreate the deleted v30 weights bit-for-bit. It preserves causal attribution inside the new matched experiment because v50 and control share the same foundation. Historical absolute values remain diagnostic only. For a direct v49-versus-v50 component claim, both variants must be retrained from the same resolved foundation.

---

# v51 FAR-DBAP — Foundation-Anchored Residual Decision-Boundary Action Preservation

Date: 2026-07-30

## Trigger: v50 open-loop gate failed

Fresh v50 output showed:

- teacher action match: candidate `0.068`, matched foundation control `0.134`;
- winner-rival sign accuracy: `0.506` vs `0.678`;
- near-tie sign accuracy: `0.307` vs `0.494`;
- evidence sufficiency: `0.0770` vs `0.0674` (`+0.00965`, not enough to recover decisions);
- teacher regret mean: `13113.5` vs `10486.8`;
- candidate paired regret median/p90/CVaR90 all regressed;
- latency p95: `1161 ms`, with prediction stage, not exact selector, now the dominant cost.

The best v50 epoch was epoch 1. Later validation degraded monotonically enough to identify full-model/interface drift rather than under-training. The rebuilt four-epoch foundation was itself weak and therefore unsuitable as an unquestioned residual anchor.

## What v50 did validate

The v50 best checkpoint still showed a useful residual signal:

- local pair-full match `0.050` -> gated residual pair-full match `0.068`;
- beneficial residual intervention `0.026` > harmful intervention `0.008`.

AOCC execution was also healthy:

- exact tournament target active `1.0`;
- calibrated bound active `1.0`;
- certified pair fraction `0.752`;
- fixed-budget fill `16/16`;
- frontier retained weight `0.804`.

Therefore v51 preserves AOCC/certificate/budget logic and repairs the foundation/residual interface instead of replacing the selector.

## Algorithm diagnosis

1. The v50 foundation was too weak for causal residual attribution.
2. Full-model fine-tuning changed the base/local interface and damaged pair ordering.
3. A direct foundation `pair_head` was silently reused as a residual-over-local head because tensor shapes matched, despite incompatible semantics.
4. Residual authorization used evidence-only local margin and ignored the base margin that participates in the final action decision.
5. Near-boundary pairs received less trust, and full disagreement suppression prevented the residual from correcting anchor-wrong pairs.
6. The v50 control used a different v43 runtime/selector configuration, confounding the comparison.
7. Invalid candidate `inf - inf` subtraction produced runtime warnings and could contaminate margin statistics.

## v51 algorithm changes

### 1. Strong foundation gate

Added `bdse/configs/v51_strong_foundation_anchor_2gpu.yaml` and `bdse.tools.check_v51_foundation_quality`.

The foundation is rebuilt for 12 epochs with normalized base loss and is replayed before v51 training. Residual training is blocked unless the foundation meets minimum teacher-match, pair-interface, sign-accuracy, sufficiency, and latency thresholds.

### 2. Immutable foundation interface

The v51 main run freezes all parameters except:

- `pair_head`;
- `pair_var_head`;
- `proposal_feature_proj`;
- `family_embed`;
- `family_activity_proj`;
- `family_head`;
- `proposal_head`.

This prevents base/local representation drift and makes the residual stage causally interpretable.

### 3. Semantic warm-start reset

Added `training.reinitialize_modules_after_warm_start` and `_reinitialize_modules_after_warm_start`.

V51 resets `pair_head` and `pair_var_head` after loading the foundation, because a direct pair predictor is not a valid residual predictor even if shapes match. Reset parameters are broadcast in DDP.

### 4. Foundation-anchored losses

Added:

- `L_anchor_preserve`: do not reduce teacher-correct far-anchor signed margin below a configured ratio/minimum;
- `L_anchor_correct`: correct foundation-wrong and near-tie pairs toward a capped teacher-directed margin.

Both operate on the deployed gated margin and are configured through `training.foundation_anchor_objective` and loss weights `anchor_preservation` / `anchor_correction`.

### 5. Full-margin certified residual gate

`confidence_shrunk_residual_pair_delta_{numpy,torch}` now accepts the normalized base margin.

The anchor is:

```text
full foundation margin = base pair margin + local evidence pair margin
```

Trust is highest near the full anchor boundary. Non-confident corrections are capped so they cannot flip a non-zero anchor. A flip is allowed only when the uncertainty-shrunk residual magnitude crosses the full anchor plus a positive flip margin.

### 6. Three-way causal protocol

Added matched configs for:

- candidate: v51 FAR residual enabled;
- local control: the same v51 checkpoint and runtime with residual intervention disabled;
- foundation control: the foundation checkpoint with matched v51 runtime/selector.

Each arm is independently calibrated and evaluated on identical deterministic replay keys. `check_v51_far_dbap_gate.py` checks residual-only gain, total gain, paired regret, exact selector coverage, certificate/fill/fallback/latency, and training health. CL20 runs only after PASS.

### 7. Non-finite invalid-candidate fix

Tournament pair-margin construction and BDSE metrics now sanitize invalid-candidate infinite costs using the shared finite-cost policy before subtraction. Scale estimation uses valid-valid margins only.

## New files

- `V51_FAR_DBAP_NEXT_COMMANDS.sh`
- `run_v51_far_dbap.sh`
- `NEXT_COMMANDS_V51_FAR_DBAP.txt`
- `README_V51_FAR_DBAP.md`
- `V51_FAR_DBAP_ANALYSIS_AND_NEXT_STEPS.md`
- `V50_RESULT_DIAGNOSIS.json`
- `bdse/configs/v51_strong_foundation_anchor_2gpu.yaml`
- `bdse/configs/v51_far_dbap_train_2gpu.yaml`
- `bdse/configs/v51_far_dbap_cl.yaml`
- `bdse/configs/v51_far_dbap_local_control_cl.yaml`
- `bdse/configs/v51_far_dbap_anchor_control_cl.yaml`
- `bdse/tools/check_v51_foundation_quality.py`
- `bdse/tools/check_v51_far_dbap_gate.py`
- `bdse/tests/test_v51_far_dbap.py`

## Validation

- Python compile: passed;
- all five v51 YAML files load and training schedule validation passes;
- shell syntax: passed;
- full unit suite: **173 passed, 6 warnings**;
- far full-anchor no-unconfident-flip: passed;
- near-boundary certified flip: passed;
- warm-start reset and frozen-interface test: passed;
- invalid-candidate non-finite margin test: passed.

## Main-run command policy

Use a new `OUT_ROOT`, `FOUNDATION_POLICY=rebuild`, `RECOVER_SAFE_FOUNDATION_COPIES=0`, and `ALLOW_ALGORITHM_CHECKPOINT_INIT=0`. Do not reuse the weak four-epoch v50 foundation. The foundation gate must pass before v51 training.

## Claim boundary

V51 supplies a cleaner novelty and theorem route: budgeted AOCC compression plus uncertainty-certified residual intervention on the complete decision boundary. It has not yet been trained or simulated in the current environment. No empirical SOTA or closed-loop improvement is claimed until fresh three-way open-loop and paired closed-loop results pass the gates.

## v51.1 Engineering/algorithm gate separation

The known prediction-stage latency is now reported separately from the causal algorithm-quality gate by default. `ENFORCE_LATENCY_BEFORE_CL=0` permits paired CL20 when action-quality/AOCC checks pass, while still marking the run as ineligible for a real-time claim. Set `ENFORCE_LATENCY_BEFORE_CL=1` to make the 500 ms target a hard prerequisite. This prevents an engineering bottleneck from hiding whether FAR-DBAP improves closed-loop decisions. The gate marker also depends on the gate source file, so changes to gate logic invalidate stale PASS markers.

---

# v52 BFAR-DBAP — Boundary-Focused Anchor-Residual Decision-Budget Action Preservation

Date: 2026-07-31

## Trigger: v51 stopped at an over-constrained foundation gate

The uploaded v51 run did not train FAR-DBAP or execute closed loop. It stopped after the foundation replay because the old gate required direct pair-head and budget-selector quality from modules that would later be reset/trained.

Observed immutable-interface quality:

- full interface action match `0.359`;
- base winner-rival sign `0.671`;
- dense winner-rival sign `0.803`;
- dense near-tie sign `0.706`;
- dense all-pair sign `0.718`;
- teacher regret `10808`.

Observed downstream-head/selector quality:

- direct pair-full action match `0.060`;
- direct pair near-tie sign `0.342`;
- certified pair fraction `0.210`;
- fallback `0.791`.

The first group is sufficient for an immutable anchor; the second group must be learned in the BFAR stage and is no longer part of the anchor gate.

## Training-speed diagnosis

- non-exact foundation epochs: `2509–2796 s`;
- full-exact epoch: `4725 s`;
- exact selector cost: `0.3146 s/step`;
- data wait and H2D: approximately `1 ms/step` each.

The dominant costs were dense pair/loss/backward and all-scene exact CPU selector work, not data loading.

## V52 algorithm changes

### 1. Immutable anchor-only gate

Added `bdse.tools.check_v52_anchor_quality`. It gates only the base+dense-local interface that remains frozen. Direct pair head, proposal selection, evidence sufficiency and AOCC coverage are explicitly excluded.

The uploaded v51 checkpoint passes this corrected gate. The recommended main run reuses that checkpoint instead of rebuilding another foundation.

### 2. Factorized fast anchor fallback

Added `bdse/configs/v52_factorized_anchor_fast_2gpu.yaml` for cases where no usable anchor exists:

- direct pair-conditioned inference disabled;
- exact deployment selector training disabled;
- only scene/action/evidence/query/base/local modules train;
- normalized base/local decision losses retained;
- batch/chunk settings enlarged.

### 3. Quota-constrained boundary pair curriculum

Added `_boundary_focused_pair_subsample` in `bdse.experiments.train`.

Most optimizer steps keep 64 pairs and reserve overlapping quotas for:

- teacher-winner/rival pairs;
- hard-feasibility crossings;
- near-tie pairs.

Remaining slots use a deterministic joint decision-weight score. This prevents abundant hard pairs from evicting all near-boundary pairs. Full pair graphs are restored on exact AOCC steps and in the final alignment tail.

### 4. Periodic exact full-graph AOCC supervision

The main run uses:

- batch size 8 per GPU;
- exact selector on 1 scene/rank every 4 steps;
- full batch exact selector for the final 128 steps;
- process backend with 4 workers/rank.

Ordinary exact scene coverage is `1 / (8 * 4) = 3.125%`, with a short final full-alignment tail. The gate now requires sparse exact supervision rather than the impossible historical 99% average.

### 5. Primary-budget exactness with sparse auxiliary budgets

B=16 is evaluated at every exact event. B=8/B=24 are sampled only every fourth exact event as robustness regularizers. This preserves the fixed-budget paper objective while reducing expensive CPU selector calls.

### 6. Core-idea evidence gate

`check_v52_bfar_dbap_gate.py` now directly requires:

- proposal decisive recall;
- selected decisive recall;
- effective decisive recall;
- selected interaction-decisive recall;
- AOCC certificate/frontier/fill;
- residual-only and total action gains;
- paired regret non-regression.

This ties the empirical gate to the paper statement that retained evidence must preserve or correctly change action ordering under B=16.

### 7. Training-health gate repair

The gate checks finite critical loss/timing metrics and sparse exact coverage. Optional diagnostics with zero denominators may be NaN without invalidating training. The old requirement that every epoch have near-100% exact coverage was removed.

### 8. Provenance and launcher fixes

- added `FOUNDATION_SOURCE_CONFIG` so an explicitly reused v51 checkpoint is recorded with its actual training config;
- fixed factorized-anchor checkpoint naming across launcher and pipeline;
- exposed batch size, worker count and sparse selector cadence as environment variables;
- retained algorithm/latency gate separation and three-way paired controls.

## Main algorithm statement

V52 BFAR-DBAP learns a fixed-budget evidence coreset over flip-critical action pairs, anchored to the complete base+local decision margin. A residual may change an action ordering only when its uncertainty-shrunk correction is certified against the full anchor margin. Far-correct pairs receive do-no-harm supervision; near-tie and anchor-wrong pairs receive correction supervision.

## New files

- `V52_BFAR_DBAP_NEXT_COMMANDS.sh`
- `run_v52_bfar_dbap.sh`
- `NEXT_COMMANDS_V52_BFAR_DBAP.txt`
- `README_V52_BFAR_DBAP.md`
- `V52_BFAR_DBAP_ANALYSIS_AND_NEXT_STEPS.md`
- `V51_RESULT_DIAGNOSIS.json`
- `bdse/configs/v52_factorized_anchor_fast_2gpu.yaml`
- `bdse/configs/v52_bfar_dbap_train_2gpu.yaml`
- `bdse/configs/v52_bfar_dbap_cl.yaml`
- `bdse/configs/v52_bfar_dbap_local_control_cl.yaml`
- `bdse/configs/v52_bfar_dbap_anchor_control_cl.yaml`
- `bdse/tools/check_v52_anchor_quality.py`
- `bdse/tools/check_v52_bfar_dbap_gate.py`
- `bdse/tests/test_v52_bfar_dbap.py`

## Claim boundary

V51 provides no residual or closed-loop result because the pipeline stopped before those stages. V52 has been code-validated locally but not trained on nuPlan in this environment. No closed-loop or SOTA claim is made before fresh three-way replay and paired CL evaluation.

---

# v53 WC-BFAR-DBAP — Winner-Consistent Boundary-Focused Anchor-Residual Decision-Budget Action Preservation

Date: 2026-07-31

## Trigger: v52 was blocked before the algorithm stage

The uploaded v52 pipeline did not train BFAR-DBAP and did not execute three-way open-loop or closed-loop evaluation. It stopped at the reused-foundation gate. The only hard failure was:

- `teacher_regret=12761.731177 > 12000`.

This was a semantic gate error. `teacher_regret` is the final budgeted/runtime action regret, not the regret of the frozen base+dense-local anchor. Between v51 and v52, the same checkpoint and the same 1000 scenario keys produced identical teacher, dense full-interface and local pair-full actions, while the budgeted action changed in 833/1000 rows because the runtime configuration changed. The immutable anchor metrics remained unchanged:

- full-interface action match `0.359`;
- base winner-rival sign `0.671`;
- dense winner-rival sign `0.803`;
- dense near-tie sign `0.706`;
- dense all-pair sign `0.718`.

Consequently, v52 provides no empirical test of its boundary sampler, periodic exact selector distillation, residual learning, or fixed-budget closed-loop benefit.

## 1. Correct immutable-anchor gate

Added `bdse/tools/check_v53_anchor_quality.py`.

The gate checks only the interface that is actually frozen during residual training:

- base+dense-local action match;
- base winner-rival sign;
- dense winner-rival, near-tie and all-pair sign;
- replay cardinality, unique scenario/timestamp keys and a SHA-256 key fingerprint.

It explicitly excludes budgeted regret, direct pair-head quality, proposal recall, selector quality and AOCC certification. Full-interface regret and latency are diagnostics only. The uploaded v52 replay passes this corrected gate.

## 2. Correct anchor-specific regret metrics

Added explicit metrics so future gates cannot confuse runtime actions with immutable interfaces:

- `base_interface_teacher_regret`;
- `full_interface_teacher_regret`;
- `sparse_full_interface_teacher_regret`;
- `pair_full_teacher_regret`;
- `local_pair_full_teacher_regret`.

## 3. Removed zero-gradient action objectives

V52 assigned high weights to `full_action` and `full_margin`, but both are computed from frozen base+local outputs in the residual stage. They therefore contributed no gradient to the trainable residual or selector heads and only inflated the logged total loss.

V53 sets both weights to zero and skips their forward computation when all frozen full-interface objectives are disabled.

## 4. Winner-consistent residual tournament learning

Added three objectives that act on trainable residual-dependent logits:

- `L_pair_full_action`: teacher-action cross entropy on the all-evidence residual tournament;
- `L_pair_full_winner_margin`: teacher winner versus strongest valid rival margin;
- `L_budget_preserve_pair_full`: B=16 action must preserve the pair-full winner whenever that winner is teacher-correct.

These objectives connect residual margin learning and fixed-budget evidence selection directly to action ordering rather than average pair reconstruction.

## 5. Safe no-op residual initialization

After loading the reused foundation and resetting semantically incompatible heads:

- the last residual pair-head layer is initialized to exactly zero;
- the pair-variance head starts from a configurable constant uncertainty bias;
- base/local parameters remain unchanged.

The candidate therefore starts exactly at the frozen anchor rather than immediately introducing random action flips.

## 6. Retained BFAR main line

The following v52 mechanisms are retained because they were never tested and remain aligned with the paper idea:

- winner-rival, hard-feasibility-crossing and near-tie pair quotas;
- maximum 64 boundary-critical pairs on ordinary steps;
- periodic full-pair-graph exact AOCC supervision;
- B=16 as the primary exact deployment budget;
- sparse B=8/B=24 robustness supervision;
- full-margin uncertainty-certified residual intervention;
- counterfactual decisive-evidence and do-no-harm losses;
- independent calibration and three-way paired controls.

## 7. Additional training-speed changes

- cycle/transitivity topology mining runs every 4 steps instead of every step;
- maximum sampled consistency triangles reduced from 64 to 48;
- final full-graph/full-exact alignment tail reduced from 128 to 64 steps;
- stale frozen full-interface objective computation is skipped;
- exact CPU process backend and v52 boundary-pair sparsification are retained.

No surrogate replaces the deployed exact B=16 selector.

## 8. Two-tier evaluation gate

Added `bdse/tools/check_v53_wc_bfar_dbap_gate.py`.

### Minimum-completeness gate

Controls whether paired CL20 runs. It rejects catastrophic action/regret regression, broken pairing, missing exact supervision, failed calibration, budget violations, severe harmful residual behavior and gross loss of decisive evidence. It does not require a paper-grade improvement before any closed-loop evidence can be collected.

### Competitive gate

Controls CL100/paper-result escalation. It retains strict requirements on:

- candidate gain over foundation and same-checkpoint local control;
- pair-full residual gain;
- beneficial versus harmful interventions;
- decisive and interaction-decisive recall;
- AOCC certification/frontier/fallback;
- paired median and p90 regret non-regression.

Latency remains an independent deployment warning unless `ENFORCE_LATENCY_BEFORE_CL=1`.

## 9. Claim boundary

V53 fixes the gate semantics and the missing winner-gradient path. It has passed local code/unit validation, but has not been trained or simulated on nuPlan in this environment. No gate PASS, closed-loop gain, fixed-budget SOTA or real-time claim is made before a fresh v53 run.

---

# v54 AR-BFAR-DBAP — Anchor-Relative Boundary-Focused Residual Decision-Budget Action Preservation

Date: 2026-07-31

## Trigger: V53 selector succeeded at preserving the wrong pair winner

V53 is the first run in this branch that completed fresh residual/selector training, independent three-way calibration, and three paired 1000-scene open-loop replays. Its immutable anchor gate passed, but both the minimum-completeness and competitive gates failed, and the launcher stopped before CL20.

V53 candidate metrics:

- teacher action match: `0.100`;
- matched foundation teacher action match: `0.116`;
- dense full-interface action match: `0.359`;
- B=16 selected-local sparse action match: `0.141`;
- local pair-full action match: `0.118`;
- residual pair-full action match: `0.100`;
- proposal/selected/effective decisive recall: `0.801/0.588/0.754`;
- interaction-decisive recall: `0.555`;
- AOCC certificate: `0.821`;
- fallback: `0.157`;
- budget-vs-pair-full action match: `0.987`;
- beneficial/harmful residual intervention: `0.015/0.033`.

The selector and certificate therefore reached the previous competitive coverage targets, but they preserved a weak pair-full action target. The primary bottleneck is the pair tournament interface, not exact coreset search.

## 1. Engineering gate repair

V53 computed frozen anchor drift by comparing different interfaces:

- candidate `local_pair_full_interface_action_match`;
- local-control `pair_full_interface_action_match`.

V54 compares row-wise, same-interface actions instead:

- candidate/local `local_pair_full_action`;
- candidate/local `full_action`.

Both corrected drifts are exactly zero on the uploaded V53 replay. The corrected protocol-integrity gate passes.

## 2. Diagnostic closed-loop on minimum failure

V53 stopped after the minimum gate and produced no CL20. V54 introduces three gate tiers:

1. protocol-integrity: failure blocks all closed-loop evaluation;
2. minimum-completeness: determines whether CL20 is a formal minimum-result PASS;
3. competitive: controls CL100 and paper-result escalation.

When protocol integrity passes but minimum performance fails, `RUN_DIAGNOSTIC_CL20_ON_GATE_FAIL=1` runs fully paired candidate/local/foundation CL20 and writes `.diagnostic_cl20`. This prevents repeated open-loop-only iterations while keeping the result clearly separated from a publication PASS.

## 3. Selected-local integrable tournament anchor

V53 reconstructed the pair tournament from `J0` plus queried pair edges. Missing edges fell back to the base margin and discarded the selected evidence's local action costs. The resulting graph could be non-integrable and inconsistent even when dense/local pair signs were strong.

V54 first constructs the selected-local action cost:

`J_B^L(a) = J0(a) + sum_{i in S_B} g_i(a)`.

The learned pair prediction is decomposed into its known local component and a residual:

`r_B(a,b) = pair_delta(a,b) - local_delta(a,b)`.

The tournament margin becomes:

`m_B^AR(a,b) = J_B^L(a) - J_B^L(b) + r_B(a,b)`.

At zero residual, the tournament exactly reproduces the selected-local B=16 planner. This is now enforced in both differentiable training and runtime inference.

## 4. Full-margin action-anchor guard

The runtime records the selected-local anchor action before applying residual pair corrections. A proposed residual action flip is accepted only if:

- the uncertainty-shrunk proposed-vs-anchor pair margin exceeds the configured flip margin;
- the proposed tournament score improves over the anchor winner;
- validity and safety masks allow the action.

Otherwise the final action is restored to the selected-local anchor. New diagnostics report the proposed/anchor actions, robust margin, score gain, and whether the flip was blocked or accepted.

## 5. Anchor-relative winner objectives

Full-evidence training starts from `J0 + sum_all g`; B=16 training starts from `J0 + sum_selected g`. The pair head only supplies a residual correction.

New/updated objectives:

- `pair_full_anchor_preserve`: keep the full-local winner when it is teacher-correct;
- `budget_preserve_pair_full`: keep the selected-local winner when it is teacher-correct;
- teacher-action and strongest-rival correction on anchor-wrong scenes;
- `anchor_wrong_action_weight` upweights correctable anchor errors;
- existing do-no-harm, counterfactual decisive evidence, certificate and proposal losses are retained.

## 6. Further speed reduction

V54 changes the residual/selector schedule:

- epochs: `6 -> 4`;
- ordinary boundary pairs: `64 -> 48`;
- full graph cadence: every `4 -> 8` steps;
- exact B=16 supervision cadence: every `4 -> 8` steps;
- final full-exact tail: `64 -> 32` steps;
- cycle/transitivity cadence: every `4 -> 8` steps;
- maximum consistency triangles: `48 -> 32`.

The deployed B=16 selector remains exact AOCC. No surrogate replaces deployment selection.

## 7. V53 findings by core issue

1. Pair sign to action: not solved. Strong dense signs did not survive the reconstructed pair graph.
2. Decisive evidence selection: coverage/certification is largely solved, but the certified target winner is wrong.
3. Training compute: substantially improved. V53 reduced epoch time to approximately 20–30 minutes from V51's roughly 42–79 minutes.

## 8. New files

- `V54_AR_BFAR_DBAP_NEXT_COMMANDS.sh`;
- `run_v54_ar_bfar_dbap.sh`;
- `NEXT_COMMANDS_V54_AR_BFAR.txt`;
- `README_V54_AR_BFAR.md`;
- `V54_AR_BFAR_ANALYSIS_AND_NEXT_STEPS.md`;
- `V53_RESULT_DIAGNOSIS.json`;
- `V54_GATE_ON_V53.json`;
- `bdse/configs/v54_ar_bfar_dbap_train_2gpu.yaml`;
- `bdse/configs/v54_ar_bfar_dbap_cl.yaml`;
- `bdse/configs/v54_ar_bfar_dbap_local_control_cl.yaml`;
- `bdse/configs/v54_ar_bfar_dbap_anchor_control_cl.yaml`;
- `bdse/tools/check_v54_ar_bfar_dbap_gate.py`;
- `bdse/tests/test_v54_ar_bfar.py`.

## 9. Claim boundary

V54 has been code-validated and the corrected gate has been replayed on V53 outputs. It has not been trained or simulated on nuPlan in this environment. No future gate PASS, closed-loop improvement, fixed-budget SOTA, or real-time claim is made before fresh V54 training and paired CL20.

---

# V55 PC-BFAR-DBAP update — 2026-07-31

Version: **Potential-Consistent Boundary-Focused Anchor-Residual Decision-Budget Action Preservation**.

## 1. V54 experimental diagnosis

The uploaded V54 run completed fresh residual/selector training, three independent calibrations, and three paired 1000-scene open-loop replays. It did not run CL20 or CL100.

V54 gate status:

- immutable anchor gate: PASS;
- protocol gate: FAIL only because `selector_exact_fraction=0.02572` was compared against a hard-coded `0.03`;
- configured train floor: `0.015`;
- minimum failure list: empty;
- competitive gate: FAIL.

Replaying the same results with a config-derived exact-fraction floor gives protocol PASS and minimum PASS, while competitive remains FAIL. Therefore the missing CL20 was caused by an engineering gate mismatch, but the lack of competitive action gain is algorithmic.

Key V54 observations:

- candidate/local/foundation final teacher match: `0.118/0.118/0.118`;
- local pair-full match: `0.118`;
- sparse all-local-evidence match: `0.141`;
- dense full-interface match: `0.359`;
- candidate-local deployed action differences: `0/1000`;
- beneficial/harmful causal residual interventions: `0/0`;
- pair-full match: `0.118`;
- budget-vs-pair-full match: `0.992`;
- proposal/selected/effective decisive recall: approximately `0.800/0.577/0.743`;
- fallback: `0.156`;
- frontier retained: `0.759`;
- epoch time: approximately `17–20` minutes.

The selector and sparse training schedule remain useful. The action aggregation path is the primary bottleneck.

## 2. Engineering gate fix

`check_v55_pc_bfar_dbap_gate.py` now reads `training.min_deployment_exact_fraction` from the actual train config. A command-line value can raise the floor, but the gate no longer silently imposes an unrelated hard-coded threshold.

The V54 replay passes V55 protocol and minimum gates and correctly fails only the competitive gate.

## 3. Pure same-checkpoint local control

V54 disabled residual mean but left residual variance active. Variance still affected AOCC and tournament uncertainty and produced five internal `local_pair_full -> pair_full` action changes in 1000 scenes.

V55 makes `disable_pair_residual_intervention=true` disable both:

- selector/tournament residual mean;
- selector/tournament residual variance.

The local control is therefore causally isolated from the residual head.

## 4. Direct selected-local action anchor

V54 inserted selected-local margins into a restricted-rival tournament, but still selected the action through tournament traversal. Zero residual was not guaranteed to equal the direct B=16 selected-local argmin.

V55 constructs:

`J_B^L(a) = J0(a) + sum_{i in S_B} g_i(a)`

and uses its direct global argmin/scores as the action anchor. At zero residual the deployed action exactly equals the selected-local planner, independently of pair variance and rival graph coverage.

## 5. Potential-consistent residual aggregation

Independent pair residuals can contain cycles and violate global action transitivity. V55 projects the selected residual edge field onto an integrable action potential:

`phi* = argmin_phi sum_(a,b) w_ab ((phi_b-phi_a)-r_ab)^2 + lambda ||phi||^2`.

Boundary pairs receive larger weights. Only the conservative potential component can change action costs:

`J_B^PC(a) = J_B^L(a) + scale * phi(a)`.

The non-conservative component is reported through reconstruction and cycle diagnostics and is penalized during training rather than being allowed to alter the winner through an arbitrary tournament path.

## 6. Global certified residual flip

A potential-corrected action may replace the selected-local winner only when:

- its direct corrected cost is better;
- the uncertainty-shrunk proposed-vs-anchor global margin exceeds the flip threshold;
- validity and safety guards permit the action.

Pair variance no longer changes anchor scores directly; it is used only for certification.

## 7. Action-potential distillation

V55 adds a direct global target for the residual potential based on the teacher-versus-selected-local cost correction. The target is centered per scene and robustly scaled. It upweights:

- the teacher winner;
- the selected-local strongest rival;
- actions near the teacher decision boundary;
- scenes where the selected-local anchor is wrong.

This provides a real gradient from preserved evidence to the final global winner, instead of relying only on average independent pair signs.

## 8. Deployment target alignment

Periodic exact AOCC training can target the full Top-M integrable-potential action. Thus the exact B=16 selector is trained to preserve the same downstream action definition used at deployment.

Deployment still uses exact AOCC. No surrogate selector replaces the B=16 method.

## 9. Gate and diagnostics

V55 records:

- direct selected-local anchor action and regret;
- deployed-vs-selected-local match;
- potential proposed/allowed/deployed flip rates;
- causal paired candidate-vs-local beneficial/harmful rates;
- projection reconstruction RMSE;
- cycle fraction;
- potential correction magnitude.

If protocol integrity passes, paired diagnostic CL20 is run even when the minimum or competitive gate fails. CL100 remains blocked unless the competitive gate passes.

## 10. Preserved designs

The following V52–V54 designs are retained:

- winner/hard/near-tie boundary-pair curriculum;
- ordinary 48-pair training graph;
- periodic full graph and exact B=16 supervision;
- final short full-exact alignment tail;
- exact AOCC and counterfactual decisive-evidence targets;
- B=16 fixed evidence budget;
- same-checkpoint local and matched-foundation controls;
- independent calibration and paired replay;
- algorithm and latency gates remain separated.

## 11. New files

- `V55_PC_BFAR_DBAP_NEXT_COMMANDS.sh`;
- `run_v55_pc_bfar_dbap.sh`;
- `NEXT_COMMANDS_V55_PC_BFAR.txt`;
- `README_V55_PC_BFAR.md`;
- `V55_PC_BFAR_ANALYSIS_AND_NEXT_STEPS.md`;
- `V54_RESULT_DIAGNOSIS.json`;
- `V55_GATE_ON_V54.json`;
- `bdse/model/potential_projection.py`;
- `bdse/configs/v55_pc_bfar_dbap_train_2gpu.yaml`;
- `bdse/configs/v55_pc_bfar_dbap_cl.yaml`;
- `bdse/configs/v55_pc_bfar_dbap_local_control_cl.yaml`;
- `bdse/configs/v55_pc_bfar_dbap_anchor_control_cl.yaml`;
- `bdse/tools/check_v55_pc_bfar_dbap_gate.py`;
- `bdse/tests/test_v55_pc_bfar.py`.

## 12. Validation and claim boundary

Validation completed:

- Python compile: PASS;
- four V55 YAML files: PASS;
- shell syntax: PASS;
- unit tests: `194 passed, 7 warnings`;
- V54 replay with corrected gate: protocol PASS, minimum PASS, competitive FAIL.

No fresh V55 nuPlan training or closed-loop simulation was run in this environment. No future gate PASS, closed-loop gain, fixed-budget CCF-A result, SOTA, or real-time claim is made in advance.

---

# V56 DCIP-BFAR-DBAP update — 2026-08-01

Version: **Dual-Certificate Integrable-Potential Boundary-Focused Anchor-Residual Decision-Budget Action Preservation**.

## 1. V55 experimental diagnosis

The uploaded V55 run completed fresh residual/selector training, independent three-way calibration, paired 1000-scene open-loop replay, and paired diagnostic CL20.

Gate status:

- protocol: PASS;
- minimum: FAIL;
- competitive: FAIL.

Minimum failures were `certificate=0.204 < 0.40` and `fallback=0.801 > 0.60`. The same-checkpoint residual-disabled local control had certificate `0.888`, fully-certified scenes `0.805`, and fallback `0.11`, while candidate and local deployed actions were identical on all 1000 rows. The minimum failure was therefore primarily caused by residual uncertainty contaminating the evidence certificate.

Competitive failure was real:

- candidate/local/foundation teacher match: `0.141/0.141/0.141`;
- pair-full/local-pair-full match: `0.141/0.141`;
- candidate-local deployed flips: `0/1000`;
- beneficial/harmful residual interventions: `0/0`;
- paired regret delta: `0`.

## 2. Closed-loop runtime diagnosis

Three paired diagnostic CL20 branches completed:

- candidate wall time: `22,858 s`;
- local control: `15,924 s`;
- foundation control: `14,914 s`;
- sequential three-way total: `53,696 s` (`14.92 h`).

Each 10-scenario GPU shard constructed and loaded ten independent CUDA planner/model instances. Prediction dominated one open-loop planner call at approximately `685 ms`, compared with selector `89 ms` and tournament `6 ms`. Duplicate CUDA model loading and device contention were the primary avoidable engineering bottlenecks.

The combined closed-loop summary also reported `num_scenarios=10` despite an actual `scenario_count=20` because the combiner weighted the count field like a metric.

## 3. Shared-model closed-loop execution

V56 adds one process-global model cache keyed by checkpoint, model architecture, and device. All planners in one nuPlan worker process reuse the same read-only eval model.

- model construction remains under a cache lock, preventing concurrent duplicate CUDA allocation;
- a per-device reentrant inference lock serializes GPU forward passes while allowing CPU simulation workers to overlap;
- default `CL_WORKERS_PER_GPU` is increased to four;
- OpenMP/MKL/BLAS threads are limited to one per worker;
- summary PDF/histogram rendering is disabled by default;
- per-stage closed-loop timing is aggregated to JSON;
- combined summaries use the true scenario count;
- candidate/local/foundation CL20 scenario-token hashes are checked before accepting the paired result.

No fixed speedup is claimed before a server run.

## 4. Dual evidence/residual certificates

V55 used one certificate for both evidence sufficiency and residual uncertainty. Residual variance could therefore collapse AOCC certification even when the residual did not change the action.

V56 separates:

- **evidence certificate**: exact AOCC over selected-local evidence margins only;
- **residual flip certificate**: a global uncertainty-shrunk guard applied only when the residual action potential proposes a winner change.

The gate consumes `evidence_certificate_fraction` when available and records residual-flip certification separately.

## 5. Direct evidence-attributable integrable potential

V55 learned an arbitrary residual pair field and projected it through Hodge decomposition. The field could be cyclic before projection, and a scene-level potential target did not identify which evidence should correct which action.

V56 predicts one signed residual action potential per evidence/action query:

`h_i(a) = residual_action_head(scene, action, evidence_i, query_i(a))`.

For selected evidence set `S_B`:

`J_B^DCIP(a) = J0(a) + sum_{i in S_B} g_i(a) + scale * sum_{i in S_B} h_i(a)`.

Every pair correction is a difference of one global action cost, so antisymmetry and cycle consistency hold exactly. The legacy pair MLP is skipped in training and deployment.

All V56 train/closed-loop configurations explicitly set `model.evidence_action_residual=true`; this is required to execute the new head rather than returning a zero potential.

## 6. Atomwise causal-potential distillation

The cache provides teacher per-evidence action costs. V56 adds:

`h_i^T(a) = [g_i^teacher(a) - g_i^local(a)] / scene_scale`.

Target and prediction are gauge-centered over valid actions. The loss upweights:

- the teacher winner;
- the selected-local anchor action when it is wrong;
- interaction evidence;
- anchor-wrong scenes;
- atoms/actions with larger teacher-minus-local correction.

This resolves the identifiability problem of scene-level-only potential distillation. The global potential target remains with a lower weight as a consistency loss.

## 7. Exact selected-local no-op and pure controls

With zero residual potential, the deployed action is exactly the direct B=16 selected-local argmin, independent of pair graph coverage and pair variance.

When `disable_pair_residual_intervention=true`, both residual potential and residual variance are removed. Candidate-local differences can therefore be attributed to the residual-potential module.

## 8. Preserved effective designs

V56 retains:

- factorized base+dense-local foundation anchor;
- winner/hard/near-tie boundary-pair curriculum;
- ordinary 48-pair training graph;
- periodic full graph and sparse exact B=16 supervision;
- final short full-exact alignment tail;
- exact AOCC and counterfactual decisive-evidence targets;
- fixed B=16 decision budget;
- same-checkpoint local and matched-foundation controls;
- independent calibration and paired replay;
- diagnostic CL20 whenever protocol integrity passes;
- algorithm and latency gates remain separate.

## 9. Partial test-set policy

The uploaded partial test diagnostics contain `67,042` unique identities with no internal duplicates and the same candidate/evidence/teacher/preprocess configuration as validation. It is harder than validation, but it has no split manifest or train/val overlap audit and represents only about 28% of the intended cache.

V56 adds `RUN_V56_PRELIMINARY_TEST.sh`. It requires `V56_TEST_FROZEN_ACK=YES`, records checkpoint/config hashes, and is intended only for one-shot evaluation after all training and thresholds are frozen. It must not be used for tuning or called a final paper test set.

## 10. New files

- `V56_DCIP_BFAR_DBAP_NEXT_COMMANDS.sh`;
- `run_v56_dcip_bfar_dbap.sh`;
- `NEXT_COMMANDS_V56_DCIP_BFAR.txt`;
- `README_V56_DCIP_BFAR.md`;
- `V56_DCIP_BFAR_ANALYSIS_AND_NEXT_STEPS.md`;
- `V55_RESULT_DIAGNOSIS.json`;
- `V55_PARTIAL_TEST_READINESS.json`;
- `RUN_V56_PRELIMINARY_TEST.sh`;
- `bdse/configs/v56_dcip_bfar_dbap_train_2gpu.yaml`;
- `bdse/configs/v56_dcip_bfar_dbap_cl.yaml`;
- `bdse/configs/v56_dcip_bfar_dbap_local_control_cl.yaml`;
- `bdse/configs/v56_dcip_bfar_dbap_anchor_control_cl.yaml`;
- `bdse/tools/check_v56_dcip_bfar_dbap_gate.py`;
- `bdse/tests/test_v56_dcip_bfar.py`.

## 11. Validation and claim boundary

Validation completed:

- Python compile: PASS;
- four V56 YAML files: PASS;
- shell syntax: PASS;
- unit tests: `201 passed, 8 warnings`;
- direct action-potential integrability/no-op/certified-correction tests: PASS;
- shared model cache-key control test: PASS;
- partial test readiness audit: preliminary PASS with manifest warnings.

No fresh V56 nuPlan training or closed-loop simulation was run in this environment. No future minimum/competitive gate PASS, closed-loop speedup, fixed-budget CCF-A result, SOTA, or real-time claim is made in advance.

### V56 post-validation protocol clarification: explicit NR/R closed-loop mode

The uploaded V55 `CL20` command used `closed_loop_nonreactive_agents`; it was not a reactive closed-loop benchmark.  V56 now makes the challenge explicit through `CL_CHALLENGE` and derives the matching metric aggregator.  The default remains non-reactive for fast diagnostic iteration, while a frozen checkpoint can be evaluated with `CL_CHALLENGE=closed_loop_reactive_agents` under a separate `OUT_ROOT`.  Unsupported challenge names fail before nuPlan starts, preventing NR and R summaries from being silently mixed.

### V56 pre-release exact-selector alignment fix

A final end-to-end code audit found that `skip_pair_head_forward=true` removed `pair_atom_delta`, while the exact-selector training mask still required that legacy tensor.  Without the fix, periodic exact AOCC supervision would silently return an empty mask (or the NumPy cache would raise on the first exact step), so the new direct evidence-potential head could train without the intended deployment-selector supervision.  V56 now derives each evidence atom's certificate delta directly from the selected-local action field, `g_i(b)-g_i(a)`, when the dual-certificate/direct-potential route is active.  The full-TopM exact target is the selected-local anchor action, matching runtime AOCC; the residual action potential is excluded from the evidence certificate and is handled only by the downstream residual-flip certificate.  A regression test verifies exact selection without a legacy pair head.

### V56 frozen reactive CL20 runner

Added `RUN_V56_REACTIVE_CL20.sh`.  The uploaded V55 CL20 was non-reactive; the new runner reuses the already frozen V56 checkpoint and three calibrated configs, runs candidate/local/foundation under `closed_loop_reactive_agents`, writes to a separate output root, and verifies the three scenario-token hashes.  It never retrains and prevents non-reactive and reactive summaries from being mixed.

---

# V57 WC-DCIP-BFAR-DBAP update — 2026-08-02

Version: **Winner-Correction Dual-Certificate Integrable-Potential Boundary-Focused Anchor-Residual Decision-Budget Action Preservation**.

## 1. V56 result diagnosis

The uploaded V56 run completed training, three independent calibrations, and paired 1000-scene open-loop evaluation. The archive contains no closed-loop output; the claimed paired reactive CL20 is therefore not part of the evidence analyzed in this update.

V56 gate state:

- protocol: FAIL;
- formal minimum: FAIL, with `minimum_failures=[]`;
- competitive: FAIL.

Open-loop state:

- candidate/local/foundation teacher match: `0.140/0.141/0.141`;
- pair-full/local-pair-full match: `0.141/0.141`;
- evidence certificate: `0.888033`;
- fallback: `0.111`;
- proposal/selected/effective decisive recall: `0.798152/0.606437/0.772101`;
- interaction decisive recall: `0.575137`;
- deployed residual flip rate: `0.005`;
- beneficial/harmful deployed residual rate: `0.000/0.001`.

Paired row analysis found five candidate-local deployed flips: zero exact teacher-winner corrections, one harmful correction, and four teacher-match-neutral changes. Internal pair-full residual changed 17 winners, with one beneficial and one harmful change. V56 therefore learned non-zero perturbations but not a net useful final-winner correction.

## 2. Root cause of the protocol failure

V56 set the legacy aggregate `training.loss_weights.action` to zero while assigning non-zero weights to deployment selection, pair-full winner, budget preservation, certificate, and action-potential objectives.

The loss implementation incorrectly used `loss_weights.action > 0` as the master switch for the entire action/winner/deployment family. This silently disabled:

- exact deployment selector supervision;
- deployment-mask distillation;
- selected-budget action loss;
- pair-full action and winner-margin losses;
- budget-to-pair-full preservation;
- pair-full anchor preservation;
- global action-potential teacher loss.

All five V56 epochs consequently reported `selector_exact_fraction=0` and zero for every winner-level objective. Only atomwise residual distillation remained active and stayed nearly flat around `0.0117`.

A second audit found that the multi-budget selected-B branch did not pass `residual_action_potential` into the direct-potential logits. Even after enabling the family, the deployed-budget winner objective could therefore remain disconnected from the residual head.

## 3. Minimum-gate interpretation

V56 solved the V55 evidence/residual certificate mixing at the evidence-gate level:

- certificate recovered from `0.204` to `0.888`;
- fallback recovered from `0.801` to `0.111`.

The formal minimum label was false only because the gate defined `minimum_pass = protocol_pass and minimum_metrics_pass`. V57 reports `minimum_metrics_pass` separately.

The dual-certificate implementation was still incomplete:

- residual and dual-certificate aggregate metrics were NaN;
- the tournament did not consume the evidence certificate before authorizing a residual flip;
- a harmful flip was deployed at evidence-certificate fraction `0.2`.

## 4. Winner/deployment action-family activation

V57 replaces the legacy aggregate master switch with a family-level predicate. The winner/deployment branch activates when any relevant sub-objective has non-zero weight, including:

- deployment selection;
- certificate gap/safety/frontier;
- pair-full action and winner margin;
- budget preservation;
- pair-full anchor preservation;
- action-potential teacher distillation;
- residual winner correction.

The V57 main configuration deliberately retains `loss_weights.action=0` as a regression guard: child objectives must execute independently.

Training now reports `action_family_enabled`.

## 5. Direct selected-budget potential gradient repair

All direct-potential action paths now receive `residual_action_potential`:

- full-support action potential;
- early oracle-selected action potential;
- predicted multi-budget/B=16 action potential.

A regression test verifies that a selected evidence potential changes the budgeted winner and backpropagates a non-zero gradient into the residual potential.

## 6. Winner-directed residual correction

V57 adds `L_residual_winner_correction`.

For an anchor-wrong scene, the corrected teacher winner must outrank the exact selected-local anchor winner by a configured correction margin. For an anchor-correct scene, the corrected teacher winner must retain a preservation margin over the strongest valid rival.

This objective directly optimizes the deployed intervention role instead of assuming that atomwise residual reconstruction will automatically improve the final winner.

The term is intentionally named winner correction, not counterfactual or causal intervention: the current cache provides comparative teacher/local labels, not a separate intervention dataset.

## 7. Independent residual uncertainty training

V57 trains `residual_action_var_head` against detached atomwise residual error in log-variance space.

- the variance target cannot absorb or alter the residual mean target;
- residual uncertainty never enters the evidence certificate;
- it is used only by the residual-flip certificate;
- `residual_action_var_head` is explicitly included in the trainable-module set.

## 8. Enforced dual-certificate deployment

The residual winner may change only when both certificates pass:

1. evidence certificate fraction meets the configured threshold;
2. residual robust margin and score gain meet the flip guard.

The main V57 configuration requires a fully certified evidence frontier before a residual flip:

`min_evidence_certificate_fraction_for_residual_flip = 1.0`.

The structural post-processing path is also prevented from reintroducing a residual flip that the certificate rejected.

Full-support pair diagnostics pass evidence-certificate fraction `1.0` and use the same post-structural finalization as deployment.

## 9. Metric and gate observability

Open-loop evaluation now propagates:

- evidence certificate fraction;
- residual flip proposed/deployed;
- residual flip certificate pass;
- dual-certificate deployment status;
- evidence-certificate guard diagnostics.

The V57 protocol gate fails when any configured winner/deployment supervision is silently inactive:

- no exact selector supervision;
- action family never active;
- all winner-level losses zero;
- deployment-selection distillation zero.

The gate separately reports:

- `minimum_metrics_pass`;
- formal `minimum_pass` including the protocol prerequisite;
- `competitive_metrics_pass`;
- formal `competitive_pass`.

## 10. Preserved designs

V57 retains the designs that V56 evidence supports:

- immutable base+dense-local foundation anchor;
- winner/hard/near-tie boundary-pair curriculum;
- sparse periodic exact AOCC and final exact tail;
- fixed B=16 evidence budget;
- direct per-evidence integrable action potential;
- dual evidence/residual certificate definition;
- same-checkpoint local and matched-foundation controls;
- independent calibration and paired replay;
- shared-model closed-loop execution;
- separate non-reactive and reactive closed-loop protocols.

V57 does not restore arbitrary pair fields, Hodge projection, scene-level-only potential supervision, or full-pair/full-scene exact training on every optimizer step.

## 11. Required experiment order

1. Run `RUN_V57_TRAINING_SMOKE.sh` on 1024 train / 256 validation scenes for one epoch.
2. Continue only if action-family, exact selector, deployment-selection, pair-full action, winner-correction, and residual-uncertainty signals are all non-zero.
3. Run the complete six-epoch pipeline, independent calibration, and paired 1000-scene open loop.
4. Require protocol PASS before interpreting any algorithm gate or closed-loop result.
5. Run paired NR-CL20 and frozen paired R-CL20.
6. Run CL100 only after competitive PASS and beneficial residual interventions exceed harmful interventions.
7. Run the partial test once only after checkpoint, calibration, and thresholds are frozen.

## 12. New and changed files

- `V56_RESULT_ANALYSIS_AND_V57_OPTIMIZATION.md`;
- `V56_RESULT_DIAGNOSIS_FOR_V57.json`;
- `NEXT_COMMANDS_V57_WC_DCIP_BFAR.txt`;
- `RUN_V57_TRAINING_SMOKE.sh`;
- `V57_WCD_CIP_BFAR_DBAP_NEXT_COMMANDS.sh`;
- `run_v57_wcdcip_bfar_dbap.sh`;
- `RUN_V57_REACTIVE_CL20.sh`;
- `RUN_V57_PRELIMINARY_TEST.sh`;
- `bdse/configs/v57_wcdcip_bfar_dbap_train_2gpu.yaml`;
- `bdse/configs/v57_wcdcip_bfar_dbap_cl.yaml`;
- `bdse/configs/v57_wcdcip_bfar_dbap_local_control_cl.yaml`;
- `bdse/configs/v57_wcdcip_bfar_dbap_anchor_control_cl.yaml`;
- `bdse/tools/check_v57_wcdcip_bfar_dbap_gate.py`;
- `bdse/tests/test_v57_wcdcip_bfar.py`.

Core modified modules:

- `bdse/model/losses.py`;
- `bdse/planner/tournament.py`;
- `bdse/planner/nuplan_planner.py`;
- `bdse/metrics/bdse_metrics.py`;
- `bdse/experiments/evaluate_open_loop.py`.

Historical V56 gate and unit-test files are left unchanged so the V56 record remains reproducible.

## 13. Validation and claim boundary

Validation completed:

- Python compile: PASS;
- four V57 YAML files: PASS;
- five V57 shell runners: PASS;
- unit tests: `208 passed, 8 warnings`;
- action-family master-switch regression: PASS;
- direct selected-budget potential gradient: PASS;
- evidence-certificate flip blocking/allowing: PASS;
- protocol/minimum-metrics separation: PASS.

No fresh V57 nuPlan training, open-loop evaluation, non-reactive closed loop, reactive closed loop, or CL100 was run in this environment. No future gate PASS, closed-loop gain, real-time performance, SOTA, or CCF-A-level empirical result is claimed in advance.

---

# V58 CSIP-BFAR-DBAP update — 2026-08-02

Version: **Certified Set-Aligned Integrable-Potential Boundary-Focused Anchor-Residual Decision-Budget Action Preservation**.

## 1. V57 result and gate audit

The uploaded V57 gate report recorded:

- protocol: PASS;
- minimum metrics: PASS;
- formal minimum: PASS;
- competitive: FAIL.

The strict engineering interpretation is narrower. V57's training/pairing subprotocol did pass and the V56 winner-family shutdown was repaired, but the complete dual-certificate protocol was not established because:

- the direct residual action-potential uncertainty used at deployment was never calibrated;
- residual proposal/certificate metrics were contaminated by later structural safety changes;
- paired CL20 crashed before any scenario was simulated;
- the protocol gate did not audit those conditions.

Accordingly, V57 minimum *metrics* remain a genuine PASS, but formal minimum is incomplete when full protocol validity is a prerequisite. Competitive remains a true algorithmic FAIL.

V57 open-loop state:

- candidate/local/foundation teacher match: `0.141/0.141/0.141`;
- candidate/local pair-full match: `0.141/0.141`;
- residual gain: `0.000`;
- pair-full residual gain: `0.000`;
- beneficial/harmful deployed residual: `0/0`;
- evidence certificate: `0.888033`;
- fallback: `0.110`;
- proposal/selected/effective decisive recall: `0.799339/0.607881/0.773545`;
- selected interaction decisive recall: `0.577697`.

Training evidence showed real gradients but no discrete winner learning:

- pair-full winner-margin loss: `10.0749 -> 8.1748`;
- residual winner-correction loss: `7.2338 -> 5.3785`;
- residual uncertainty loss: `3.9812 -> 2.3770`;
- atomwise residual loss remained near `0.012`;
- global action-potential teacher loss remained near `0.363`;
- B16 and pair-full action match remained `0.141`.

## 2. Runtime attribution bug

V57 froze neither the raw anchor nor the raw proposed residual action before `_finalize_pair_anchor_after_structural_guard`. The structural all-flagged guard could overwrite `pair_action_anchor_action`, after which the evaluation layer compared the proposed action with the overwritten anchor.

Of 99 reported residual proposals in 1000 scenes:

- 86 were genuine raw residual proposals rejected by the margin/uncertainty certificate;
- 13 were structural-guard action changes misreported as residual proposals;
- deployed residual flips were zero.

V58 stores immutable raw anchor/proposed actions, raw residual margin, residual sigma, and residual conformal epsilon before structural post-processing. Proposal-conditional pass rates, no-proposal abstention, structural changes, and deployed flips are now distinct metrics.

## 3. Closed-loop callback failure

V57 set:

`main_callback.metric_summary_callback=null`

nuPlan dereferenced the callback config and raised:

`AttributeError: 'NoneType' object has no attribute '_target_'`

Both CL20 shards failed before simulation. V58 keeps a valid callback, optionally removes PDFs only after success, and writes `.closed_loop_complete.json` only when all shard and merge steps complete. Three-way CL20 also requires identical scenario-token hashes and counts.

## 4. Calibration redesign

V57 ran candidate, local, and foundation calibration sequentially, consuming about 116 minutes. The three passes calibrated the legacy pair-atom adverse bound, not the direct residual action-potential margin uncertainty used by V57's flip guard. Candidate and local calibration outputs were nearly identical.

V58 replaces them with one dual-certificate collection:

- `val_calib` is sharded across both GPUs;
- shared evidence adverse scores are collected once;
- candidate proposal-conditional residual margin nonconformity is collected once;
- evidence and residual split-conformal epsilons are merged into one artifact;
- controls reuse only the evidence epsilon and have residual mean, variance, certificate, and residual epsilon disabled;
- train/calibration/runtime uncertainty beta is fixed to `1.0`.

Evidence calibration is applied only to AOCC/adverse certificate fields. It no longer mutates the tournament action rule or its independent epsilon.

## 5. Concurrent open-loop suite

V57 ran candidate, local, and foundation formal open-loop sequentially. V58 adds `bdse.tools.run_parallel_open_loop_suite`:

- all systems enter one bounded CPU/GPU worker pool;
- the same modulo shards are used for every system;
- default concurrency is two workers per GPU;
- scenario/timestamp keys must be nonempty and unique;
- all compared systems must have identical count and SHA-256 before the suite is accepted;
- per-task and suite wall times are persisted.

`BENCHMARK_V58_OPEN_LOOP_CONCURRENCY.sh` compares one, two, and three workers per GPU on a short paired run so machine-specific GPU contention can be measured instead of guessed.

Prediction remains the main V57 open-loop cost (~441 ms of ~586 ms mean latency). V58 does not yet reuse candidate/local prediction in one process; that is a future high-value refactor after the corrected protocol is validated.

## 6. Certified set-aligned winner objective

V57 optimized ordinary winner margins but not the robust margin actually required by deployment. It could therefore reduce soft losses while every proposed correction remained below the certificate threshold.

V58 adds `L_certified_residual_winner`, defined on the primary selected evidence set and aligned with deployment:

`robust_margin = corrected_margin - beta * residual_sigma - residual_epsilon`.

For an anchor-wrong scene, a correction is trained only when the frozen teacher establishes a minimum true winner margin. For an anchor-correct scene, the teacher winner must preserve a robust margin over the strongest valid rival. This creates an explicit do-no-harm term.

A configurable `residual_epsilon_reserve` is included during training because the frozen split-conformal residual epsilon is installed only after checkpoint selection.

## 7. Residual learning-rate groups

The selector and anchor-related heads already have useful behavior, while the zero-initialized residual mean remained sub-threshold. V58 introduces named optimizer groups:

- residual action mean head: `5x` base LR;
- residual action variance head: `2x` base LR;
- proposal/family/selector-related heads: `1x` base LR.

Gradient clipping still receives the complete flat parameter list. A smoke test verifies both LR groups are present and all configured winner/certificate losses execute.

## 8. Competitive checkpoint selection

V57 selected epoch 3 using a score dominated by fixed-budget evidence quality, even though residual and pair-full gains were zero for all checkpoints and proposal recall exceeded 0.80 only at epoch 5.

V58 adds `val_competitive_score`, which explicitly rewards:

- candidate teacher match;
- candidate minus selected-local gain;
- pair-full minus local pair-full gain;
- beneficial minus harmful interventions;
- selected and interaction decisive recall;
- low fallback.

The V58 training config uses this score as the primary checkpoint metric. This does not guarantee a positive residual checkpoint; it prevents a selector-only checkpoint from being preferred without accounting for the paper's winner-correction claim.

## 9. Stricter protocol and gate health checks

The V58 gate audits:

- action-family activation;
- nonzero exact-selector fraction;
- every configured winner/deployment loss individually, including certified winner loss;
- residual uncertainty supervision;
- independent evidence calibration;
- shared evidence epsilon across candidate/local/foundation;
- candidate-only residual calibration and residual-enabled deployment;
- residual-disabled controls with zero residual epsilon;
- train/deploy uncertainty beta agreement;
- exact paired scenario hashes and counts.

It reports protocol, minimum metrics, formal minimum, competitive metrics, and formal competitive separately. A protocol failure blocks closed-loop interpretation.

## 10. Preserved algorithmic components

V58 preserves components supported by V57 evidence:

- immutable base+dense-local foundation anchor;
- boundary-focused winner/hard/near-tie pair curriculum;
- sparse periodic exact AOCC and exact tail;
- fixed B=16 evidence budget;
- direct per-evidence integrable action potential;
- separate evidence and residual certificates;
- same-checkpoint local and matched-foundation controls;
- group-disjoint tune/calibration split;
- paired replay and token hashing;
- shared-model closed-loop execution.

V58 does not restore arbitrary pair fields, Hodge projection, scene-level-only potential supervision, or per-step full exact training.

## 11. Required V58 experiment order

1. Run `RUN_V58_TRAINING_SMOKE.sh` on 1024 train / 256 validation scenes.
2. Require nonzero action-family, exact-selector, deployment-selection, pair-full action, winner correction, certified winner, residual uncertainty, and correctable-scene metrics, plus `5x/2x` LR groups.
3. Run eight-epoch training.
4. Run the two-GPU shared dual-certificate calibration.
5. Run simultaneous candidate/local/foundation 1000-scene open-loop with bounded concurrency.
6. Require strict protocol PASS before interpreting minimum, competitive, or closed-loop results.
7. Run paired NR-CL20, then frozen paired R-CL20.
8. Run CL100 only after open-loop residual gain is positive, beneficial exceeds harmful, and CL20 has no safety regression.

If V58 still has zero pair-full residual gain while certified supervision is active, the next algorithmic branch should be a zero-initialized set-conditioned interaction potential head. Threshold relaxation or unconditional residual scale inflation should not be the next action.

## 12. New and changed files

New:

- `V57_RESULT_ANALYSIS_AND_V58_OPTIMIZATION.md`;
- `V57_RESULT_DIAGNOSIS_FOR_V58.json`;
- `NEXT_COMMANDS_V58_CSIP_BFAR.txt`;
- `RUN_V58_TRAINING_SMOKE.sh`;
- `BENCHMARK_V58_OPEN_LOOP_CONCURRENCY.sh`;
- `V58_CSIP_BFAR_DBAP_NEXT_COMMANDS.sh`;
- `run_v58_csip_bfar_dbap.sh`;
- `RUN_V58_REACTIVE_CL20.sh`;
- `bdse/configs/v58_csip_bfar_dbap_train_2gpu.yaml`;
- `bdse/configs/v58_csip_bfar_dbap_cl.yaml`;
- `bdse/configs/v58_csip_bfar_dbap_local_control_cl.yaml`;
- `bdse/configs/v58_csip_bfar_dbap_anchor_control_cl.yaml`;
- `bdse/tools/calibrate_v58_dual_certificates.py`;
- `bdse/tools/apply_v58_dual_calibration.py`;
- `bdse/tools/run_parallel_open_loop_suite.py`;
- `bdse/tools/check_v58_csip_bfar_dbap_gate.py`;
- `bdse/tests/test_v58_csip_bfar.py`.

Core modified:

- `bdse/model/losses.py`;
- `bdse/experiments/train.py`;
- `bdse/planner/tournament.py`;
- `bdse/planner/nuplan_planner.py`;
- `bdse/metrics/bdse_metrics.py`.

## 13. Validation and claim boundary

Completed in the analysis environment:

- Python compile: PASS;
- four V58 YAML files: PASS;
- shell syntax: PASS;
- unit tests: `215 passed, 8 warnings`;
- raw residual attribution regression: PASS;
- certified robust-winner loss regression: PASS;
- dual-calibration application regression: PASS;
- LR parameter-group regression: PASS;
- strict gate audit regression: PASS.

No fresh V58 nuPlan training, calibration, open-loop, non-reactive closed loop, reactive closed loop, or CL100 was executed here. No future gate PASS, closed-loop improvement, real-time claim, SOTA claim, or CCF-A-level empirical result is asserted in advance.

---

# V59 FSCIP-BFAR-DBAP — V58结果诊断、闭环工程修复与集合条件残差（2026-08-03）

## 1. V58冻结结果

V58 原始 open-loop gate 报告：

- Protocol gate：PASS；
- Minimum metrics / formal minimum gate：PASS；
- Competitive metrics / formal competitive gate：FAIL。

V58 在 1000 个配对场景上保持：candidate/local/foundation teacher match 均为 `0.141`，pair-full candidate/local 均为 `0.141`，最终 residual gain、pair-full residual gain、beneficial/harmful 均为零。Competitive FAIL 是真实算法失败，而不是阈值边缘失败。

V58 的正向证据集中在 evidence path：proposal decisive recall `0.80247`、selected decisive recall `0.61065`、effective decisive recall `0.77631`、interaction decisive recall `0.57934`、evidence certificate `0.88803`、fallback `0.110`。因此 V59 不回退 selector/AOCC 主线。

## 2. V58闭环结果不可用

V58 candidate CL20 两个 shard 都完成了长时间仿真，但在 `SimulationLogCallback` 序列化 planner 时触发：

```text
TypeError: cannot pickle '_thread.RLock' object
```

两个 shard 最终均报告 `successful=0, failed=10`。旧脚本仍生成 combined summary 和 `.closed_loop_complete.json`，所以这些文件不能作为闭环结果。Local control 仅开始运行，三路 paired CL20 并未完成。

V59 修复：

- `BDSEPlannerCore.__getstate__/__setstate__` 删除进程本地 RLock；
- 默认删除 `callback.simulation_log_callback`，保留 metric main callbacks；
- 合并前强制逐 shard 检查成功数等于 token 数且失败数为零；
- 只有全部 shard 验证通过后才写 `.closed_loop_complete.json`。

## 3. V58耗时根因

流水线近似耗时：anchor gate 13 分钟、8 epoch 训练 2 小时 40 分钟、双证书 calibration 25 分钟、三路并发 open-loop 9.8 分钟。正式 open-loop 不是主要瓶颈。

Candidate CL20 从 gate 后运行约 3.1–3.6 小时仍以 20/20 失败结束。profile 显示 80% planner call 命中 plan cache，但所有调用平均 core plan 仍为 25.9–29.4 秒，其中 certificate stages 14.5–16.7 秒、final safety 4.76–4.80 秒。非缓存 replanning 的隐含成本约为每次 2 分钟以上。

根因：

1. 同一 replanning 的 route distance、agent envelope、TTC、hard/soft risk 在模型、selector、多级 fallback、rule rerank 和 final diagnostic 中重复计算；
2. 每个 fallback B/M/L stage 重复构建 batch 和执行相同 scene encoder；
3. 4 个 simulation threads 共用一份 GPU 模型与 RLock，CPU 几何工作也形成锁队列；
4. 仿真结束后序列化错误使前面的全部计算失效。

V59 增加 per-planner-call runtime safety memo、scene/context memo，并改为每 GPU 多进程、每进程一个 simulation worker。并发数必须通过 CL4 benchmark 在目标机器上选择，默认 2 process/GPU，不预先声称固定加速倍数。

## 4. V58 residual calibration问题

V58 residual calibration 只在实际 residual proposal 场景上收集分数：5000 个 calibration scenes 仅 90 个 proposal，得到 `epsilon=0.46431`，远大于训练 reserve `0.05`。1000-scene open-loop 中 raw proposal 约 1.2%，conditional residual certificate pass 为 0，所有 residual proposal 被拒绝。

V59 将 residual conformal score 改为 scene-uniform all-rival score：每个场景固定 selected-local anchor，对所有 valid rivals 计算单侧 margin error，并取该场景最坏 rival 作为一个 exchangeable calibration score。actual-proposal calibration 仅保留为 diagnostic。

第二遍工程审计发现并修复一个新实现中的键名错误：runtime 输出为 `residual_action_var`，校准器曾错误读取 `residual_action_variance`。V59 现在使用严格 helper，缺少正确 key、动作维度不一致或 sigma matrix 不完整时立即失败，禁止静默零方差校准。

## 5. V58算法判断

有效并保留：

- immutable foundation anchor；
- fixed B=16 evidence budget；
- boundary pair curriculum；
- sparse exact AOCC；
- direct integrable action potential；
- evidence/residual dual-certificate separation；
- same-checkpoint local 与 matched foundation controls；
- group-disjoint tune/calibration；
- paired open-loop concurrency 与 token hashing。

不足或无效：

- 独立 per-evidence additive residual 没有产生最终 winner correction；
- global action-potential reconstruction loss 从约 `0.372` 恶化至 `0.383`；
- atomwise residual loss 约 `0.012` 基本不变；
- certified winner loss 从约 `3.09` 降到 `2.86` 后停滞，robust winner boundary 未被跨越；
- proposal-conditional calibration 太稀疏；
- V58 checkpoint score 在所有 residual gain 为零时仍可由 selector 指标主导。

## 6. V59算法：Focused Set-Conditioned Integrable Potential

V59 在不增加 queried evidence budget 的前提下加入低秩 selected-set interaction potential：

```text
h_S(a) = sum_{i in S} h_i(a)
       + < psi(a), tanh( sum_{i in S} phi(i) / sqrt(|S|) ) > / sqrt(r)
```

其中 `r=8`。该结构直接输出 action scalar potential，诱导的 pair margins 天然 antisymmetric/cycle-consistent；它表达 additive per-evidence head 无法表达的 evidence-set interaction，同时保持论文的 fixed-budget novelty。

新增 `L_residual_boundary_margin_distill`，只在 selected-local anchor 错误且 teacher margin 足够大的 correctable scenes 上，直接拟合 teacher winner 相对当前 anchor 的 margin。V59 降低全局 reconstruction/atomwise loss 权重，提高 certified winner 与 boundary margin 权重，避免平均重构淹没最终 winner 信号。

Residual mean 与 set heads 使用 5x LR，variance head 使用 2x LR。Warm start 时 additive residual 和 set atom factor 为零，set action factor小随机初始化，保证 step 0 仍为 anchor no-op，同时允许 set head获得梯度。

## 7. V59 checkpoint与gate

Competitive checkpoint score 新增：robust margin、proposal rate，并在 residual gain 与 pair-full gain 同时非正时施加大额 penalty，防止 selector-only checkpoint 被选为 paper main checkpoint。

V59 protocol gate 新增：

- `L_residual_boundary_margin_distill` 必须实际执行；
- scene-uniform residual calibration 必须独立、覆盖至少 1000 scenes、覆盖率至少 80%；
- residual calibration epsilon、uncertainty beta 和 runtime config 必须一致；
- controls 必须关闭 additive/set residual 与 residual epsilon；
- candidate/local/foundation paired hashes、counts 和 frozen anchor rows 必须一致。

## 8. V59推荐实验顺序

1. Smoke test；要求新 boundary loss、set-head LR groups、exact selector、winner/certificate losses 非零。
2. Fresh 训练、scene-uniform calibration、三路并发 1000-scene open-loop；默认不自动运行 closed loop。
3. 先看 pair-full residual gain：若仍为零，问题仍在 residual expressivity/optimization；不得放宽 certificate。
4. 若 pair-full gain > 0 但 B16 gain = 0，强化 selector 与 set-conditioned winner coupling。
5. 若 raw proposal 有益但全部被 calibration 拒绝，检查 uniform epsilon、raw error 和 sigma；不得使用 test 调参。
6. Open-loop competitive gain 转正后运行 CL4 concurrency benchmark，再运行 paired NR-CL20 与 frozen R-CL20。
7. 只有 beneficial > harmful 且安全指标无退化后运行 CL100。

## 9. V59工程文件

新增：

- `bdse/configs/v59_fscip_bfar_dbap_{train_2gpu,cl,local_control_cl,anchor_control_cl}.yaml`；
- `bdse/tools/calibrate_v59_dual_certificates.py`；
- `bdse/tools/apply_v59_dual_calibration.py`；
- `bdse/tools/check_v59_fscip_bfar_dbap_gate.py`；
- `bdse/tests/test_v59_fscip_bfar.py`；
- `run_v59_fscip_bfar_dbap.sh`；
- `V59_FSCIP_BFAR_DBAP_NEXT_COMMANDS.sh`；
- `RUN_V59_TRAINING_SMOKE.sh`；
- `RUN_V59_REACTIVE_CL20.sh`；
- `BENCHMARK_V59_OPEN_LOOP_CONCURRENCY.sh`；
- `BENCHMARK_V59_CLOSED_LOOP_CONCURRENCY.sh`。

核心修改：

- `bdse/model/bdse_model.py`；
- `bdse/model/losses.py`；
- `bdse/planner/tournament.py`；
- `bdse/planner/fallback.py`；
- `bdse/planner/nuplan_planner.py`；
- `bdse/experiments/train.py`。

## 10. 验证边界

本地静态/单元验证通过；未在当前环境执行 fresh V59 训练、calibration、open-loop 或 nuPlan closed-loop。V59 不预先声明三个 gate PASS、闭环提升、实时性、SOTA 或 CCF-A录用级结果。
